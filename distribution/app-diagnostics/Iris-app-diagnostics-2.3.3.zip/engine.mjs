var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};


var frida_java_bridge_default=globalThis.__irisJava;
function init_node_globals() {}
function init_frida_java_bridge() {}
// core.mjs
var Gesture, Lease;
var init_core = __esm({
  "core.mjs"() {
    init_node_globals();
    Gesture = class {
      constructor(now, hold, tap) {
        this.now = now;
        this.hold = hold;
        this.tap = tap;
        this.g = null;
      }
      down(x, y, slop = 24) {
        this.g = { at: this.now(), x, y, slop, up: null, hit: false, done: false, cancel: false };
      }
      move(x, y) {
        const g = this.g;
        if (g && Math.hypot(x - g.x, y - g.y) > g.slop) g.cancel = true;
      }
      cancel() {
        if (this.g) this.g.cancel = true;
      }
      up() {
        const g = this.g;
        if (!g) return;
        g.up = this.now();
        this.finish();
      }
      nativePress() {
        const g = this.g;
        if (!g) return false;
        if (g.done || g.cancel || g.up !== null && this.now() - g.up > 500) return true;
        g.hit = true;
        this.finish();
        return true;
      }
      tick() {
        this.finish();
      }
      finish() {
        const g = this.g;
        if (!g || !g.hit || g.done || g.cancel) return;
        const end = g.up === null ? this.now() : g.up;
        if (end - g.at >= 700) {
          g.done = true;
          this.hold();
        } else if (g.up !== null) {
          g.done = true;
          this.tap();
        }
      }
    };
    Lease = class {
      constructor(now) {
        this.now = now;
        this.until = 0;
        this.permanent = false;
        this.expiry = null;
        this.status = "unregistered";
      }
      active() {
        return this.until > 0 && this.now() < this.until;
      }
      accept(data) {
        if (!data || typeof data.active !== "boolean") throw Error("Invalid license response");
        if (!data.active) {
          this.until = 0;
          this.status = data.status || "unregistered";
          return;
        }
        if (!Number.isFinite(data.serverTime) || !Number.isInteger(data.leaseSeconds) || data.leaseSeconds < 1 || data.leaseSeconds > 300) throw Error("Invalid lease");
        if (data.permanent !== true && (!Number.isFinite(data.expiresAt) || data.expiresAt <= data.serverTime || data.leaseSeconds * 1e3 > data.expiresAt - data.serverTime)) throw Error("Invalid expiration");
        this.until = this.now() + data.leaseSeconds * 1e3;
        this.permanent = data.permanent === true;
        this.expiry = data.expiresAt;
        this.status = "active";
      }
      deny() {
        this.until = 0;
        this.status = "unregistered";
      }
    };
  }
});

// monotonic.mjs
function createMonotonicClock() {
  const libc = Process.getModuleByName("libc.so");
  const read2 = new NativeFunction(libc.getExportByName("clock_gettime"), "int", ["int", "pointer"]);
  const value = Memory.alloc(Process.pointerSize * 2);
  let clockId = 7;
  if (read2(clockId, value) !== 0) clockId = 1;
  return () => {
    if (read2(clockId, value) !== 0) throw Error("monotonic clock unavailable");
    return Number(value.readS64()) * 1e3 + Number(value.add(8).readS64()) / 1e6;
  };
}
var init_monotonic = __esm({
  "monotonic.mjs"() {
    init_node_globals();
  }
});

// Typed Android client adapter. Native game callbacks only read cached monotonic state.
function createLicense(Java, handlers, options = {}) {
  const now = options.now || createMonotonicClock();
  let host = null, deadline = 0, waiting = 0;
  let state = {ready:false,checked:false,licenseStatus:'unregistered',pending:false,error:null,active:false};
  function sync(value) {
    host = value;
    const data = JSON.parse(String(host.licenseStatus()));
    const remaining = Number(data.remainingMs || 0);
    if (!Number.isFinite(remaining) || remaining < 0 || remaining > 300000) throw Error('Invalid Android lease');
    deadline = remaining > 0 ? now() + remaining : 0;
    state = {ready: data.ready === true, checked: data.checked === true, licenseStatus: data.status,
      pending: data.pending === true, error: data.error || null, active: remaining > 0};
    if (waiting && Number(data.completed) >= waiting) {
      waiting = 0;
      if (!state.error && remaining > 0) handlers.toggle();
      else if (handlers.cancel) handlers.cancel();
    }
  }
  return {
    sync,
    clock: now,
    tap() { if (!host) return; waiting = Number(host.authorize()); sync(host); },
    copy() { if (host) host.copyHwid(); },
    bindView() {},
    isActive: () => state.ready && deadline > now(),
    press() {},
    status: () => ({...state, active: state.ready && deadline > now()})
  };
}
var init_licensing = __esm({
  "licensing.mjs"() { init_node_globals(); init_core(); init_monotonic(); }
});

// agent.js
var require_agent = __commonJS({
  "agent.js"() {
    init_node_globals();
    init_frida_java_bridge();
    init_licensing();
    (() => {
      const _k = [65, 120, 105, 111, 109, 75, 101, 121];
      const _b64t = (() => {
        const t = new Uint8Array(256).fill(255), s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        for (let i = 0; i < 64; i++) t[s.charCodeAt(i)] = i;
        return t;
      })();
      const _d = (s) => {
        const n = s.length;
        let bl = (n >> 2) * 3;
        if (s[n - 1] === "=") bl--;
        if (s[n - 2] === "=") bl--;
        const o = new Uint8Array(bl);
        let j = 0;
        for (let i2 = 0; i2 < n; i2 += 4) {
          const a = _b64t[s.charCodeAt(i2)] | 0, b = _b64t[s.charCodeAt(i2 + 1)] | 0;
          const c = s.charCodeAt(i2 + 2) === 61 ? 0 : _b64t[s.charCodeAt(i2 + 2)] | 0;
          const d = s.charCodeAt(i2 + 3) === 61 ? 0 : _b64t[s.charCodeAt(i2 + 3)] | 0;
          if (j < bl) o[j] = (a << 2 | b >> 4) ^ _k[j % 8];
          j++;
          if (j < bl) o[j] = (b << 4 | c >> 2) ^ _k[j % 8];
          j++;
          if (j < bl) o[j] = (c << 6 | d) ^ _k[j % 8];
          j++;
        }
        let r = "", i = 0;
        while (i < o.length) {
          const b = o[i];
          if (b < 128) {
            r += String.fromCharCode(b);
            i++;
          } else if ((b & 224) === 192) {
            r += String.fromCharCode((b & 31) << 6 | o[i + 1] & 63);
            i += 2;
          } else if ((b & 240) === 224) {
            r += String.fromCharCode((b & 15) << 12 | (o[i + 1] & 63) << 6 | o[i + 2] & 63);
            i += 3;
          } else {
            const cp = (b & 7) << 18 | (o[i + 1] & 63) << 12 | (o[i + 2] & 63) << 6 | o[i + 3] & 63;
            r += String.fromCharCode(55296 + (cp - 65536 >> 10), 56320 + (cp - 65536 & 1023));
            i += 4;
          }
        }
        return r;
      };
      const _S = Object.freeze({
        a: "EgwICAgUDRwoHwEb",
        b: "EgwICAgCCwo1GQcMCAwJFiMZBT8ZOQ==",
        c: "JhkECi8qEQ0tHQ==",
        d: "AxkdGwEuKBYlHTYMASIAFzUxBx8YPygYLxkOCh8=",
        e: "AxkdGwEuKBYlHTYHDDgNMiQB",
        f: "AxkdGwEuKBYlHTYHDDgNPC8ZCwMILw==",
        g: "AxkdGwEuKBYlHTYADyEAGjU1CAEMLAALEQwb",
        h: "DhoDCg4/KBgvGQ4KHxQKGysdChseChcLIAE=",
        i: "DhoDCg4/KBgvGQ4KHxQGFjQWHQ==",
        j: "DRcOBg4JBA01FAwiAi8AOi0RDAEZFAYMMwoMARkfDBoq",
        k: "FREFCiAqFSY2EQ0bBQ==",
        l: "FREFCiAqFSYpHQAIBT8=",
        m: "BhkECiIpDyYpER0fAiILDTI=",
        n: "BhkECiIpDyY1ARkKOyIXDTQZBQ==",
        o: "AhQACgM/LBcxDR0wFQ==",
        p: "AhQACgM/LBcxDR0wFA==",
        q: "AhQACgM/LBcxDR0wHiICFyAMHB0I",
        r: "AhQACgM/LBcxDR0wACQTHAAWDgMI",
        s: "AhQACgM/LBcxDR0wACQTHBEZGw4A",
        t: "AhQACgM/LBcxDR0wGTIVHA==",
        u: "AhQACgM/LBcxDR0wHiIfHA==",
        v: "AhQACgM/LBcxDR0wDiQLCjUKHAwZJBcmKBYd",
        w: "AhQACgM/LBcxDR0iDCUEHiQKNg4JLywXMQ0d",
        x: "AhQACgM/LBcxDR0wCi4RPSgKDAwZIgoXABYOAwg=",
        y: "DRcOBg4JBA01FAwiAi8AOi0RDAEZFBYcNTsFBgglESkzHQ0GDj8MFi81BhkIHwo=",
        z: "DRcOBg4JBA01FAwiAi8AOi0RDAEZFDoeJAw9BgEuKBgx",
        aa: "JREICCsnBB4=",
        ab: "MRkdBwsiCx0=",
        ac: "DRcOBg4JBA01FAwiAi8AOi0RDAEZFAIcNTceAT0nBAAkCj0KDCY=",
        ad: "BhkECiAqDBceJxwfCSoRHA==",
        ae: "DRcOBg4JBA01FAwiAi8AOi0RDAEZFBAJJRkdCg==",
        af: "BhkECioeLDouFh0OBCUACx4bHQAfDRcWLCsdHQQlAgo=",
        ag: "BhkECi8+EQ0uFiobAjk=",
        ah: "Ag0aGwImJww1DAYBMjgADQwXHwYICAkQMQ==",
        ai: "Ag0aGwImJww1DAYBMiQLOzQMHQADGxccMgsMCw==",
        aj: "EgwbBgMsMRgjFAwwCi4RNC4OAAouJwwJ",
        ak: "EgwICAgUBB0lOwEGAS8=",
        al: "BREaHwEqHDYjEgwMGRQWHDUgMA==",
        am: "BREaHwEqHDYjEgwMGRQWHDUrCg4BLg==",
        an: "BREaHwEqHDYjEgwMGRQXHCwXHworOQoUERkbCgM/",
        ao: "DBcfBggICRAxJw4KGR8AATU+AAoBLycADxkECg==",
        ap: "DBcfBggICRAxJw4AGSQkFyUrHQAdDRcYLB0gAQkuHQ==",
        aq: "DBcfBggICRAxMAwDHS4XJjIdHSsEOBUVIAEmDQcuBg0IFh0KHyoGDSgODA==",
        ar: "FR0RGysiABUlJxoKGR8AATU=",
        as: "FR0RGysiABUlJxoKGQgKFS4K",
        at: "FR0RGysiABUlJxoKGQ0KFzUrABUI",
        au: "BhkECioeLDouFh0OBCUACx4VBhkELiYVKAg=",
        av: "BhkECioeLDouFh0OBCUACx4LABUI",
        aw: "BhkECi8+EQ0uFjYcBDEA",
        ax: "BhkECi8+EQ0uFjYZGSoHFSQ=",
        ay: "AxkdGwEuKBYlHTYICD8sFzIMCAEOLg==",
        az: "LggMHQw/CgseHAwDCD8A",
        ba: "Bg0AMAouETAvCx0OAygA",
        bb: "Bg0AMB4jCg4HFAYOGS4XLSQAHS4ZDwAfIA0FGz0kFg==",
        bc: "EgwbBgMsJg0uCg==",
        bd: "Ehs6Gx8iCx4eHAwcGTkQGjU=",
        be: "DRcOBg4MBBQkNwsFCCgROi0RDAEZFAIcNSA=",
        bf: "DRcOBg4MBBQkNwsFCCgROi0RDAEZFAIcNSE=",
        bg: "DRcOBg4MBBQkNwsFCCgROi0RDAEZFAIcNTwIGww=",
        bh: "DRcOBg4PBA0gJw4KGQUEFCQ=",
        bi: "DRcOBg4IDRgzGQobCDkmFSgdBxsyLAANDREHBAgvJhgzChAODycA",
        bj: "DRcOBg4JBA01FAwiAi8AOi0RDAEZFAIcNTceAS4jBAsgGx0KHw==",
        bk: "LggMHQw/CgseFgwY",
        uiLabel: "JREaDAI5AVcmH0YNHiMEGio=",
        uiBOff: "reDNguvrj8rp",
        uiBOn: "reDNguvrj8rp",
        uiStartup: "qtn1hPniRZXY/ILM4aD10Q==",
        uiOnMsg: "reDNguvrj8rpWFNPIgU=",
        uiOffMsg: "reDNguvrj8rpWFNPIg0j",
        scUi: "MhtGGgRlFho=",
        mapBtn: "LBkZMAgvDA0uCjYKFSIRJiMNHRsCJQ==",
        scDbg: "MhtGCwgpEB5vCwo=",
        dbgTxt: "JR0LGgoUCBwvDTYbCDMR",
        txtF: "FR0RGw==",
        txtFB: "NQAd",
        libg: "LRELCEM4Cg==",
        libs: "LRELHBkqFwpvCwY=",
        libbw: "LRELHBg7AAsiHQUDMikXGDYUGhsMORZXMhc=",
        ball: "IxkFAw==",
        bErr: "FBYaGh07Cgs1HQ1PDz4MFSVCSRlae0tPdUBJDh8mU01hCgweGCIXHCU=",
        aLog: "GjkRBgImOFk=",
        lsFs: "JxcHGz4iHxw=",
        lsSc: "MhsIAwg=",
        lsGE: "JgoICwQuCw0EFggNAS4B",
        lsGS: "JgoICwQuCw0SDAgdGQ==",
        lsGM: "JgoICwQuCw0MEQ0LAS4=",
        lsGEn: "JgoICwQuCw0EFg0=",
        gS: "YkxfWlkKVg==",
        gM: "Yk1RWV8NVw==",
        gE: "YkErXCkNIw=="
      });
      const _O = Object.freeze({
        a: 704,
        b: 21288912,
        c: 40,
        d: 88,
        e: 96,
        f: 112,
        g: 40,
        h: 0,
        i: 12,
        j: 76,
        k: 212,
        l: 216,
        m: 196,
        n: 40,
        o: 12,
        p: 16,
        q: 56,
        r: 48,
        s: 52,
        t: 8,
        u: 72,
        v: 17207108,
        w: 12042088,
        x: 6343136,
        y: 17487848,
        z: 17487364,
        aa: 16397840,
        ab: 17870776,
        ac: 17486556,
        ad: 8146276,
        ae: 17479280,
        af: 9578456,
        ag: 9570092,
        ah: 8247172,
        ai: 9571632,
        aj: 5791600,
        ak: 6279876,
        al: 6265584,
        am: 6265604,
        an: 6266448,
        ao: 6562188,
        ap: 6558136,
        aq: 15046476,
        ar: 6252916,
        as: 6253092,
        at: 6252832,
        au: 144,
        av: 224,
        aw: 608,
        ax: 20756224,
        ay: 14680296,
        az: 20628688,
        ba: 9529128,
        bb: 9531968,
        bc: 7008916,
        bd: 7008628,
        be: 16622292,
        bf: 16622300,
        bg: 16621340,
        bh: 15858888,
        bi: 16394960,
        bj: 17487492,
        bk: 20628752
      });
      const NULL2 = ptr(0);
      const BUILD_ID = "f142792df366a11459e1547f039c84dd5d340248";
      const _NW = [[5791600, 2847833085], [6252832, 2847833085], [6252916, 3506488319], [6253092, 2847833085], [6265584, 505757696], [6266448, 2852127720], [6279876, 4181739520], [6343136, 704643112], [6558136, 2847833085], [6562188, 2847702013], [7008628, 3107980296], [7008916, 2847767549], [8146276, 3506553855], [8247172, 2847767549], [9529128, 3489685512], [9531968, 4229697512], [9570092, 2847833085], [9571632, 2847833085], [9578456, 2847767549], [12042088, 2847570941], [15046476, 3019899488], [15858888, 4181722112], [16394960, 2847702013], [16397840, 2847833085], [16621340, 4181723136], [16622292, 3107991552], [16622300, 3107992576], [17207108, 2835381279], [17479280, 3506684927], [17486556, 3108037632], [17487364, 4181752832], [17487492, 4181726216], [17487848, 1384120360], [17870776, 3506553855], [20628688, 4026533136], [20628752, 4026533136], [6265604, 3170897920], [6265608, 3170900992], [6265612, 3596551104]];
      const _C0 = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580];
      const _C1 = [3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895];
      const _C2 = [666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344];
      const _C3 = [430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
      const _SHA = Object.freeze([..._C0, ..._C1, ..._C2, ..._C3]);
      const _T2S = Object.freeze([79, 62, 45, 28]);
      const _ECI = new Uint8Array(_O.u);
      const _MS = { battle: NULL2, battleClient: NULL2, checked: 0, matched: 0, mismatched: 0, blockedSends: 0 };
      const _IIM = Object.freeze([124, 77, 26, 171, 215, 197, 96, 190, 242, 227, 88, 57, 148, 133, 33, 15]);
      const _IOM = Object.freeze([22, 39, 112, 193, 189, 175, 10, 212, 152, 137, 50, 83, 254, 239, 75, 101]);
      let _lg = null, _N = null;
      const _st = {
        started: false,
        disposed: false,
        error: null,
        uiError: null,
        startupShown: false,
        requested: null,
        lastPressAt: 0,
        nextUiTryAt: 0,
        uiAttempts: 0,
        stage: NULL2,
        button: NULL2,
        buttonClip: NULL2,
        buttonText: NULL2,
        labelContainer: NULL2,
        labelClip: NULL2,
        labelText: NULL2,
        pendingLabelStyle: null,
        labelStyleDirty: true,
        hooks: [],
        destructorHooks: /* @__PURE__ */ new Set(),
        lastContextCheckAt: 0
      };
      const _mr = {
        bound: false,
        bindFailed: false,
        battleModeClient: NULL2,
        injectingMovement: false,
        pathOutput: NULL2,
        native: null
      };
      const _bs = { snapshot: null };
      const _got = /* @__PURE__ */ new Map();
      const _sso = Memory.alloc(128);
      let _ssb = false;
      const _ag = {
        enabled: false,
        lastCheckAt: 0,
        lastCarryCheckAt: 0,
        carriedKey: null,
        pickupRoute: null,
        lastWaitReason: null,
        lastMoveAt: 0,
        lastBallScanAt: 0,
        manualUntil: 0,
        stopPending: false,
        battle: NULL2,
        linkedBallName: null,
        ballDataNames: /* @__PURE__ */ new Map(),
        ball: null,
        phase: "idle",
        moveTarget: null,
        route: null,
        routeGoal: null,
        routePlan: null,
        routeFailureAt: 0,
        routePathCalls: 0,
        mapSize: null,
        goal: null,
        lastError: null
      };
// Reuse the existing native feature implementation; never load a second engine.
const _features = { module:null, bridge:null, snapshot:null, submit:null,
  buffer:Memory.alloc(112), error:'', frame:-1, seenAt:0, ready:false,
  progress:0, initialized:false, config:{} };
const _featureSlots = [1,2,4,5,9,14,16,17,18,19,25,26,48,49,50,51,52,53,54,55];
function _featuresBind() {
  if (_features.module || _features.error) return;
  if(globalThis.__irisBoot && globalThis.__irisBoot.featuresError){_features.error=globalThis.__irisBoot.featuresError;return;}
  let mod = Process.findModuleByName('libbrf.so');
  if (!mod) {
    if (!_panelHost) return;
    try {
      const error=String(_panelHost.loadNativeFeatures());
      if(error){_features.error=error;return;}
      mod=Process.findModuleByName('libbrf.so');
      if(!mod){_features.error='Native feature initialization did not load BRF';return;}
    }catch(e){_features.error=String(e);return;}
  }
  try {
    if (Process.arch !== 'arm64' || mod.size < 0x87000 ||
        mod.base.add(0x34e48).readU32() !== 0xd10343ff ||
        mod.base.add(0x33380).readU32() !== 0xa9be7bfd ||
        mod.base.add(0x3339c).readU32() !== 0x79000c3f)
      throw new Error('Unsupported feature module; original module left intact');
    const state=Memory.alloc(1024);state.writeByteArray(new Uint8Array(1024));
    const bridge = new CModule("/* Android menu bridge for the already bundled BRF 70.648 module.\n * Only this module's menu/config API is replaced, never gameplay functions.\n * Configuration is applied on its original render thread, outside the mutex.\n */\n#include <glib.h>\n#include <stdint.h>\n#include <string.h>\n\nextern void iris_apply(void *context, unsigned char *config);\ntypedef struct {\n    GMutex lock;\n    int pending[88];\n    unsigned char config[88];\n    int frame_count, frame_rate, is_ready, error, progress, interactive;\n} IrisState;\n/* CModule data pages are read-only; mutable storage is provided by the host. */\nextern IrisState iris_state;\n#define mutex iris_state.lock\n#define requested iris_state.pending\n#define observed iris_state.config\n#define frames iris_state.frame_count\n#define fps iris_state.frame_rate\n#define ready iris_state.is_ready\n#define last_error iris_state.error\n#define loading_progress iris_state.progress\n#define initialized iris_state.interactive\n\nstatic int boolean_slot(int slot) {\n    switch (slot) {\n        case 1: case 2: case 4: case 5: case 9: case 14: case 16:\n        case 17: case 18: case 19: case 25: case 26: case 48:\n        case 49: case 50: case 51: case 52: case 53: case 54: case 55:\n            return 1;\n        default: return 0;\n    }\n}\n\nint submit(int slot, int value) {\n    if (boolean_slot(slot)) { if (value < 0 || value > 1) return 0; }\n    else if (slot == 56) { if (value < 0 || value > 100) return 0; }\n    else if (slot == 60) { if (value < 0 || value > 1000) return 0; }\n    else if (slot == 64) { if (value < 10 || value > 121) return 0; }\n    else return 0; /* No farm, duplicate auto-goal, unknown offset or menu. */\n    g_mutex_lock(&mutex);\n    requested[slot] = value + 1;\n    g_mutex_unlock(&mutex);\n    return 1;\n}\n\nvoid render(void *context, void *renderer, float width, float height,\n            int progress, int current_fps, int interactive) {\n    unsigned char *ctx = context, config[88];\n    int changes[88], i, changed;\n    if (!ctx) return;\n    memcpy(config, ctx + 0x68, 88);\n    /* BRF passes interactive = (its initialization state == 3). The context\n     * API pointer is created earlier, while its worker is still installing\n     * hooks. Do not call that API or report readiness until initialization\n     * has completed. These are module progress values, not server login. */\n    if (!interactive || progress < 100 || !*(uintptr_t *)(ctx + 0xe0)) {\n        g_mutex_lock(&mutex);\n        memcpy(observed, config, 88);\n        fps = current_fps;\n        ready = 0;\n        loading_progress = progress;\n        initialized = interactive != 0;\n        frames++;\n        g_mutex_unlock(&mutex);\n        return; /* Keep requested settings queued for the first ready frame. */\n    }\n    g_mutex_lock(&mutex);\n    memcpy(changes, requested, sizeof(changes));\n    memset(requested, 0, sizeof(requested));\n    g_mutex_unlock(&mutex);\n    changed = config[3] != 0 || config[11] != 0;\n    /* Iris owns both farm and licensed goal. Do not start duplicate BRF bots. */\n    config[3] = 0; config[11] = 0;\n    for (i = 0; i < 88; i++) {\n        if (!changes[i]) continue;\n        if (boolean_slot(i)) config[i] = (unsigned char)(changes[i] - 1);\n        else { int value = changes[i] - 1; memcpy(config + i, &value, 4); }\n        changed = 1;\n    }\n    if (changed) iris_apply(context, config);\n    /* Remove original native menu hit regions. The Iris Android panel owns UI. */\n    if (*(uintptr_t *)(ctx + 0x130) != *(uintptr_t *)(ctx + 0x128)) {\n        *(uintptr_t *)(ctx + 0x130) = *(uintptr_t *)(ctx + 0x128);\n        (*(uint64_t *)(ctx + 0x198))++;\n    }\n    ctx[0x174] = 0;\n    g_mutex_lock(&mutex);\n    memcpy(observed, ctx + 0x68, 88);\n    if (changed) {\n        last_error = 0;\n        for (i = 0; i < 88; i++) if (config[i] != observed[i]) last_error = 1;\n    }\n    fps = current_fps;\n    ready = 1;\n    loading_progress = progress;\n    initialized = 1;\n    frames++;\n    g_mutex_unlock(&mutex);\n}\n\n/* Flat snapshot: [ready, frames, fps, error, config[88], progress, interactive]. */\nvoid snapshot(void *output) {\n    int *header = output;\n    g_mutex_lock(&mutex);\n    header[0] = ready; header[1] = frames; header[2] = fps; header[3] = last_error;\n    memcpy((unsigned char *)output + 16, observed, 88);\n    header[26] = loading_progress;\n    header[27] = initialized;\n    g_mutex_unlock(&mutex);\n}\n", {iris_apply:mod.base.add(0x33380),iris_state:state});
    _features.snapshot = new NativeFunction(bridge.snapshot,'void',['pointer']);
    _features.submit = new NativeFunction(bridge.submit,'int',['int','int']);
    Interceptor.replace(mod.base.add(0x34e48),bridge.render);
    _features.bridge=bridge;_features.state=state;_features.module=mod;
  } catch(e) { _features.error=String(e); }
}
function _featuresPoll() {
  _featuresBind();
  if (!_panelHost) return;
  if (!_features.snapshot) {
    if(_features.error)_panelHost.updateFeatures(JSON.stringify({ready:false,values:{},error:_features.error}));
    return;
  }
  try {
    _features.snapshot(_features.buffer);
    const p=_features.buffer, frame=p.add(4).readS32(), now=_panelTime();
    if(frame!==_features.frame){_features.frame=frame;_features.seenAt=now;}
    _features.ready=p.readS32()!==0 && now-_features.seenAt<3000;
    _features.progress=p.add(104).readS32();
    _features.initialized=p.add(108).readS32()!==0;
    for(const slot of _featureSlots) _features.config[String(slot)]=p.add(16+slot).readU8();
    for(const slot of [56,60,64]) _features.config[String(slot)]=p.add(16+slot).readS32();
    _panelHost.updateFeatures(JSON.stringify({ready:_features.ready,values:_features.config,
      fps:p.add(8).readS32(),moduleProgress:_features.progress,moduleInitialized:_features.initialized,
      error:p.add(12).readS32()?'설정을 적용하지 못했습니다':_features.error}));
    for(let i=0;i<16;i++) {
      const text=_panelHost.pollFeature();if(!text)break;
      const command=JSON.parse(String(text));
      if(_panelForeground && _features.ready && !_features.submit(command.slot,command.value))
        _features.error='Invalid feature setting';
    }
  } catch(e) { _features.error=String(e); }
}

// Client-side recovery only. A changing local tick is not a server acknowledgement.
// This code never changes packets, extends a license, or hides a server disconnect.
class ConnectionGate {
  constructor(clock) {
    this.clock=clock;this.network='unknown';this.focused=true;this.networkGeneration=null;
    this.key=null;this.tick=null;this.pulseAt=0;this.progressAt=0;this.stableAt=0;
    this.samples=0;this.epoch=0;this.barrier='waiting';this.recoveries=0;
  }
  hold(reason,now=this.clock()) {
    if(this.barrier!==reason){this.epoch++;this.barrier=reason;}
    this.samples=0;this.stableAt=now;
  }
  sync(data) {
    const state=['online','offline','unknown'].includes(data.network)?data.network:'unknown';
    const focused=data.focused===true;
    const generation=Number.isSafeInteger(data.generation)?data.generation:0;
    if(this.network!==state||this.focused!==focused||this.networkGeneration!==generation)
      this.hold(state==='offline'?'offline':!focused?'screen':'recovering');
    this.network=state;this.focused=focused;this.networkGeneration=generation;
  }
  observe(key,tick) {
    const now=this.clock();
    if(!key||!Number.isInteger(tick)){this.clear();return;}
    const changed=this.key!==key;
    const stale=this.key!==null&&(now-this.pulseAt>1800||now-this.progressAt>1800);
    const backwards=!changed&&this.tick!==null&&tick<this.tick;
    if(changed||backwards){this.hold('recovering',now);this.tick=null;}
    else if(stale)this.hold('stalled',now);
    this.key=key;this.pulseAt=now;
    if(this.tick!==tick){
      this.tick=tick;this.progressAt=now;
      if(this.focused&&this.network!=='offline'){
        if(!this.samples)this.stableAt=now;
        this.samples=Math.min(100,this.samples+1);
      }
    }
    if(this.focused&&this.network!=='offline'&&this.samples>=3&&now-this.stableAt>=600){
      if(this.barrier){this.recoveries++;this.barrier='';}
    }
  }
  clear() {
    if(this.key!==null)this.epoch++;
    this.key=null;this.tick=null;this.samples=0;this.barrier='waiting';
  }
  status() {
    const now=this.clock();let reason;
    if(!this.focused)reason='screen';
    else if(this.network==='offline')reason='offline';
    else if(this.key===null)reason='waiting';
    else if(now-this.pulseAt>1800||now-this.progressAt>1800){reason='stalled';this.hold(reason,now);}
    else if(this.samples<3||now-this.stableAt<600||this.barrier)reason='recovering';
    else reason='ready';
    return {reason,ready:reason==='ready',farmBlocked:reason==='offline'||reason==='screen'||(this.key!==null&&reason!=='ready'),
      network:this.network,epoch:this.epoch,recoveries:this.recoveries,
      tickAgeMs:this.key===null?null:Math.max(0,Math.round(now-this.progressAt))};
  }
}
const _connection=new ConnectionGate(()=>_panelTime());
let _connectionEpoch=-1;
function _connectionPrune() {
  if(_connectionEpoch===_connection.epoch)return;
  _connectionEpoch=_connection.epoch;
  _bs.snapshot=null;_ag.battle=NULL2;_ag.ball=_ag.carriedKey=_ag.pickupRoute=null;
  _ag.moveTarget=_ag.route=_ag.routeGoal=_ag.routePlan=null;
  _ag.mapSize=_ag.goal=null;_ag.routeFailureAt=0;
  _ag.lastCheckAt=_ag.lastCarryCheckAt=_ag.lastMoveAt=_ag.lastBallScanAt=0;
  if(_ag.ballDataNames)_ag.ballDataNames.clear();
}
function _connectionBeforeTick(bmc) {
  try {
    const active=_gmb();
    if(!active||active.isNull()||!active.equals(bmc)||!_cfm(bmc,256)){
      _connection.clear();_connectionPrune();return false;
    }
    if(_connection.key!==bmc.toString())_MS.battle=_MS.battleClient=NULL2;
    _connection.observe(bmc.toString(),bmc.add(_O.j).readS32());
    const status=_connection.status();_connectionPrune();
    if(!status.ready){_ag.lastWaitReason='connectionWait';return false;}
    if(_ag.lastWaitReason==='connectionWait')_ag.lastWaitReason=null;
    return true;
  }catch(error){
    _connection.hold('context');_connectionPrune();_ag.lastWaitReason='connectionWait';
    return false;
  }
}
function _connectionPoll() {
  _connection.sync(JSON.parse(String(_panelHost.connectionStatus())));
  const status=_connection.status();_connectionPrune();
  _panelHost.updateConnection(JSON.stringify(status));
  return status;
}

// Executed inside the existing licensed engine closure. No Java calls from game hooks.
let _panelHost = null, _panelPending = false, _panelAttempts = 0;
let _panelWanted = false, _panelQueued = false, _panelForeground = false, _panelError = '';
let _panelLastTick = 0;
const _Java = frida_java_bridge_default;
function _panelTime() { return _license.clock ? _license.clock() : Date.now(); }
function _panelStop() { _panelWanted = false; _panelQueued = false; _st.requested = false; }
function _panelActivate() {
  if (_panelWanted && _panelForeground && _st.started) _st.requested = true;
  _panelWanted = false; _panelQueued = false;
}
function _panelSurface(surface) {
  if (!_panelHost) return;
  try { _panelHost.attachContext(surface.getContext()); }
  catch (e) { _panelRecordError('surface', e); }
}
function _panelRecordError(stage, error) {
  _panelError=String(error);
  console.error('[IRIS BSHACK] '+stage+': '+_panelError);
  try { if(_panelHost) _panelHost.recordError(stage,_panelError); } catch (_) {}
}
function _panelInitialize(app) {
  const boot=globalThis.__irisBoot || {version:23000,name:'2.3.0',ui:'',recovery:''};
  const input = boot.ui ? _Java.use('java.io.FileInputStream').$new(boot.ui) : app.getAssets().open('iris-panel.dex');
  const out = _Java.use('java.io.ByteArrayOutputStream').$new();
  const buffer = _Java.array('byte', new Array(8192).fill(0));
  try { let n; while ((n = input.read(buffer)) > 0) out.write(buffer, 0, n); }
  finally { input.close(); }
  const bytes = out.toByteArray(); out.close();
  const loader = _Java.use('dalvik.system.InMemoryDexClassLoader').$new(
    _Java.array('java.nio.ByteBuffer',[_Java.use('java.nio.ByteBuffer').wrap(bytes)]),
    app.getApplicationInfo().nativeLibraryDir.value, app.getClassLoader());
  _panelHost = _Java.ClassFactory.get(loader).use('com.irisai.bshack.PanelHost');
  _panelHost.initialize(_Java.cast(app, _Java.use('android.app.Application')));
  _panelHost.configure(boot.version,boot.name,boot.recovery);
  console.log('[IRIS BSHACK] UI DEX loaded');
}
function _panelFindActivity() {
  const records = _Java.use('android.app.ActivityThread').currentActivityThread().mActivities.value;
  const iter = records.values().iterator();
  while (iter.hasNext()) {
    const record = _Java.cast(iter.next(), _Java.use('android.app.ActivityThread$ActivityClientRecord'));
    if (!record.paused.value && record.activity.value) {
      const activity = record.activity.value;
      _panelHost.attach(activity);
      _license.bindView(activity.getWindow().getDecorView());
    }
  }
}
function _panelPhase() {
  if (_panelError) return 'UI 연결 오류';
  if (!_st.started) return _st.error ? '게임 연결 실패' : '게임 로딩 중';
  const auth = _license.status();
  if (!auth.ready) return '인증 준비 중';
  if (auth.error) return '인증 연결 실패';
  if (_panelWanted) return '인증 확인 중';
  if (auth.checked && !auth.active) return auth.licenseStatus === 'revoked' ? '이용 정지' : auth.licenseStatus === 'expired' ? '기간 만료' : 'HWID 등록 필요';
  if(_ag.enabled){
    const reason=_connection.status().reason;
    const labels={offline:'네트워크 연결 대기',screen:'게임 화면 복귀 대기',stalled:'게임 상태 갱신 대기',recovering:'연결 안정화 중',waiting:'브롤볼 대기'};
    if(labels[reason])return labels[reason];
  }
  if (_ag.lastError) return '오토골 오류 · 다시 켜세요';
  if (_ag.enabled && _ag.lastWaitReason === 'inputRejected') return _MS.checked ? '게임 입력 연결 대기' : '조이스틱을 한 번 움직이세요';
  const labels = {idle:'브롤볼 대기',findBall:'공 찾는 중',dribble:'골대로 운반',carry:'골대로 운반',shoot:'조준 슛'};
  return labels[_ag.phase] || (_ag.enabled ? '오토골 실행 중' : '브롤볼 대기');
}
function _panelPoll() {
  if (_st.disposed || _panelPending) return;
  _panelPending = true;
  try {
    _Java.perform(() => _Java.scheduleOnMainThread(() => {
      try {
        if (!_panelHost) {
          if (++_panelAttempts > 40) return;
          const app = _Java.use('android.app.ActivityThread').currentApplication();
          if (!app) return;
          _panelInitialize(app);
        }
        if (!_panelHost.isResumed() && _panelAttempts < 40) {
          _panelAttempts++;
          try { _panelFindActivity(); } catch (e) { console.log('[IRIS BSHACK] Waiting for activity: ' + e); }
        }
        _panelForeground = _panelHost.isResumed();
        if (!_panelForeground) _panelStop();
        if(_license.sync) _license.sync(_panelHost);
        for (let i = 0; i < 8; i++) {
          const command = _panelHost.poll();
          if (!command) break;
          if (command === 2) _panelStop();
          else if (command === 3) _license.copy();
          else if (command === 1) {
            if (_ag.enabled || _st.requested === true || _panelWanted) _panelStop();
            else if (_panelForeground && (_st.started || !_st.error)) { _panelWanted = true; _panelQueued = true; }
          }
        }
        if (_panelWanted && _panelQueued && _st.started && _license.status().ready) {
          _panelQueued = false; _license.tap();
        }
        const status = _license.status();
        if (status.error && !_panelQueued) _panelWanted = false;
        _connectionPoll();
        _art();
        _featuresPoll();
        _panelHost.autoGoalPriority(_ag.enabled && !!(_ag.carriedKey || _ag.ball));
        _panelError='';_panelLastTick=_panelTime();
        if(_panelHost.recordState) _panelHost.recordState(JSON.stringify({game:_st.started,foreground:_panelForeground,enabled:_ag.enabled,phase:_ag.phase,auth:status,connection:_connection.status(),features:{ready:_features.ready,moduleProgress:_features.progress,moduleInitialized:_features.initialized,error:_features.error},lastEngineError:_ag.lastError || _st.error || null}));
        _panelHost.update(_ag.enabled, _panelPhase());
      } catch (e) { _panelRecordError('poll',e); _panelStop();try{if(_panelHost)_panelHost.update(false,'UI 연결 오류');}catch(_){} }
      finally { _panelPending = false; }
    }));
  } catch (e) { _panelPending = false; _panelStop(); _panelRecordError('schedule',e); }
}
setInterval(_panelPoll, 250);

      const _license = createLicense(frida_java_bridge_default, {
        surface: _panelSurface,
        cancel() { _panelWanted = false; },
        notice(message) { console.log("[IRIS BSHACK] " + message); },
        toggle() {
          _panelActivate();
        },
        disabled() {
          if (_ag.enabled || _st.requested === true) _st.requested = false;
        }
      });
      function _wns(text, cb) {
        const use = !_ssb, so = use ? _sso : Memory.alloc(128);
        let ctor = false;
        if (use) _ssb = true;
        try {
          _N.bc(so, Memory.allocUtf8String(text));
          ctor = true;
          return cb(so);
        } finally {
          if (ctor) try {
            _N.bd(so);
          } catch (_) {
          }
          if (use) _ssb = false;
        }
      }
      function _rss(val, max) {
        try {
          if (!val || val.isNull()) return null;
          const len = val.add(4).readS32();
          if (len <= 0 || len > max) return null;
          const data = len <= 7 ? val.add(8) : val.add(8).readPointer();
          if (!data || data.isNull()) return null;
          return data.readUtf8String(len);
        } catch (_) {
          return null;
        }
      }
      function _got2(obj) {
        if (!obj || obj.isNull()) return -1;
        const entry = obj.readPointer().add(_O.n).readPointer();
        const key = entry.toString();
        let rd = _got.get(key);
        if (rd === void 0) {
          const rng = Process.findRangeByAddress(entry);
          if (rng === null || !rng.protection.includes("x")) return -1;
          rd = new NativeFunction(entry, "int", ["pointer"]);
          _got.set(key, rd);
        }
        return rd(obj) | 0;
      }
      function _ilc(obj) {
        try {
          return _got2(obj) === 0 && obj.add(_O.m).readS32() > 0;
        } catch (_) {
          return false;
        }
      }
      function _gbs(battle, now = Date.now()) {
        if (!battle || battle.isNull()) return null;
        try {
          const mgr = battle.add(_O.g).readPointer();
          if (mgr.isNull()) return null;
          const arr = mgr.add(_O.h).readPointer();
          const cnt = mgr.add(_O.i).readU32();
          if (arr.isNull() || cnt < 1 || cnt > 1200) return null;
          const tick = battle.add(_O.j).readS32();
          const prev = _bs.snapshot;
          if (prev !== null && now - prev.at >= 0 && now - prev.at <= 8 && prev.battle.equals(battle) && prev.manager.equals(mgr) && prev.array.equals(arr) && prev.tick === tick && prev.count === cnt) return prev;
          const objs = [], ps = new Array(cnt);
          const bytes = arr.readByteArray(cnt * 8);
          if (bytes === null) return null;
          const pw = new Uint32Array(bytes);
          const ppw = prev !== null && prev.manager.equals(mgr) && prev.array.equals(arr) ? prev.pointerWords : null;
          for (let i = 0; i < cnt; i++) {
            let obj;
            const off = i * 2;
            const lo = pw[off], hi = pw[off + 1];
            if (lo === 0 && hi === 0) continue;
            if (ppw !== null && i * 2 + 1 < ppw.length && ppw[i * 2] === lo && ppw[i * 2 + 1] === hi && prev.pointerSlots[i] !== void 0) {
              obj = prev.pointerSlots[i];
            } else {
              obj = ptr("0x" + hi.toString(16).padStart(8, "0") + lo.toString(16).padStart(8, "0"));
            }
            ps[i] = obj;
            if (!obj.isNull()) objs.push(obj);
          }
          const snap = { battle: ptr(battle.toString()), manager: mgr, array: arr, count: cnt, tick, at: now, objects: objs, pointerSlots: ps, pointerWords: pw };
          _bs.snapshot = snap;
          return snap;
        } catch (_) {
          return null;
        }
      }
      function _rr(v, b) {
        return v >>> b | v << 32 - b;
      }
      function _sha256(bytes) {
        const len = bytes.length, tlen = len + 72 >> 6 << 6;
        const pool = _sha256.ws || (_sha256.ws = /* @__PURE__ */ new Map());
        let ws = tlen <= 256 ? pool.get(tlen) : null;
        if (!ws) {
          const msg2 = new Uint8Array(tlen);
          ws = { message: msg2, view: new DataView(msg2.buffer), words: new Uint32Array(64) };
          if (tlen <= 256) pool.set(tlen, ws);
        }
        const { message: msg, view, words } = ws;
        msg.fill(0);
        msg.set(bytes);
        msg[len] = 128;
        view.setUint32(tlen - 8, Math.floor(len * 8 / 4294967296), false);
        view.setUint32(tlen - 4, len * 8 >>> 0, false);
        let h0 = 1779033703, h1 = 3144134277, h2 = 1013904242, h3 = 2773480762, h4 = 1359893119, h5 = 2600822924, h6 = 528734635, h7 = 1541459225;
        for (let off = 0; off < tlen; off += 64) {
          for (let i = 0; i < 16; i++) words[i] = view.getUint32(off + i * 4, false);
          for (let i = 16; i < 64; i++) {
            const s0 = _rr(words[i - 15], 7) ^ _rr(words[i - 15], 18) ^ words[i - 15] >>> 3;
            const s1 = _rr(words[i - 2], 17) ^ _rr(words[i - 2], 19) ^ words[i - 2] >>> 10;
            words[i] = words[i - 16] + s0 + words[i - 7] + s1 >>> 0;
          }
          let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
          for (let i = 0; i < 64; i++) {
            const s1 = _rr(e, 6) ^ _rr(e, 11) ^ _rr(e, 25);
            const ch = e & f ^ ~e & g;
            const t1 = h + s1 + ch + _SHA[i] + words[i] >>> 0;
            const s0 = _rr(a, 2) ^ _rr(a, 13) ^ _rr(a, 22);
            const maj = a & b ^ a & c ^ b & c;
            const t2 = s0 + maj >>> 0;
            h = g;
            g = f;
            f = e;
            e = d + t1 >>> 0;
            d = c;
            c = b;
            b = a;
            a = t1 + t2 >>> 0;
          }
          h0 = h0 + a >>> 0;
          h1 = h1 + b >>> 0;
          h2 = h2 + c >>> 0;
          h3 = h3 + d >>> 0;
          h4 = h4 + e >>> 0;
          h5 = h5 + f >>> 0;
          h6 = h6 + g >>> 0;
          h7 = h7 + h >>> 0;
        }
        const res = new Uint8Array(32), rv = new DataView(res.buffer);
        rv.setUint32(0, h0, false);
        rv.setUint32(4, h1, false);
        rv.setUint32(8, h2, false);
        rv.setUint32(12, h3, false);
        rv.setUint32(16, h4, false);
        rv.setUint32(20, h5, false);
        rv.setUint32(24, h6, false);
        rv.setUint32(28, h7, false);
        return res;
      }
      function _bmr() {
        if (_mr.bound) return true;
        if (_mr.bindFailed) return false;
        try {
          const addr = (n) => _lg.base.add(_O[n]);
          _mr.native = Object.freeze({
            getGame: new NativeFunction(addr("ay"), "pointer", []),
            getOwnCharacter: new NativeFunction(addr("bj"), "pointer", ["pointer"]),
            getTileMap: new NativeFunction(addr("z"), "pointer", ["pointer"]),
            setPredictionPosition: new NativeFunction(addr("y"), "void", ["pointer", "int", "int", "bool"]),
            pathfind: new NativeFunction(addr("ab"), "int", ["int", "int", "int", "int", "pointer", "pointer", "bool", "int", "int", "int"]),
            getPathfindingFlag: new NativeFunction(addr("aa"), "int", ["pointer"]),
            getX: new NativeFunction(addr("be"), "int", ["pointer"]),
            getY: new NativeFunction(addr("bf"), "int", ["pointer"]),
            getOwnPlayerTeam: new NativeFunction(addr("ac"), "int", ["pointer"]),
            getGameObjectData: new NativeFunction(addr("bg"), "pointer", ["pointer"]),
            constructClientInput: new NativeFunction(addr("v"), "void", ["pointer", "int"]),
            getDirectionAngle: new NativeFunction(addr("x"), "int", ["int", "int"]),
            addInput: new NativeFunction(addr("w"), "void", ["pointer", "pointer"]),
            allocate: new NativeFunction(addr("bk"), "pointer", ["ulong"])
          });
          _mr.pathOutput = Memory.alloc(16);
          _mr.bound = true;
          _mr.bindFailed = false;
          return true;
        } catch (_) {
          _mr.native = null;
          _mr.pathOutput = NULL2;
          _mr.bound = false;
          _mr.bindFailed = true;
          return false;
        }
      }
      function _gmg() {
        if (!_mr.bound) return NULL2;
        const g = _mr.native.getGame();
        return g && !g.isNull() ? g : NULL2;
      }
      function _gmb() {
        try {
          const game=_gmg();
          if(!_cfm(game,_O.c+8))return NULL2;
          const battle=game.add(_O.c).readPointer();
          return _cfm(battle,256)?battle:NULL2;
        } catch (_) { return NULL2; }
      }
      function _gmc() {
        const b = _gmb();
        if (b.isNull()) return NULL2;
        const c = _goc(b);
        return c && !c.isNull() ? c : NULL2;
      }
      function _cis(inp, battle, write3 = true) {
        if (battle.add(_O.f).readU8() === 0) return 0;
        const key = new Uint8Array(battle.add(_O.e).readByteArray(16));
        const ib = new Uint8Array(inp.add(4).readByteArray(16));
        const type = inp.add(_O.t).readU32();
        if (type !== 2) return 0;
        let ws = _cis.workspace;
        if (!ws) {
          const inn = new Uint8Array(84), out = new Uint8Array(96);
          inn.fill(54, 16, 64);
          out.fill(92, 16, 64);
          ws = _cis.workspace = { inner: inn, outer: out };
        }
        const im = ws.inner, om = ws.outer;
        for (let i = 0; i < 16; i++) {
          im[i] = key[i] ^ _IIM[i];
          om[i] = key[i] ^ _IOM[i];
        }
        for (let i = 0; i < 12; i++) im[64 + i] = ib[4 + i];
        for (let i = 0; i < 4; i++) im[76 + i] = ib[i];
        im.set(_T2S, 80);
        om.set(_sha256(im), 64);
        const dg = _sha256(om);
        let sig = (dg[0] | (dg[1] & 127) << 8) >>> 0;
        if (sig <= 1) sig = 1;
        if (write3) inp.add(_O.q).writeU32(sig);
        return sig;
      }
      function _ons(mgr, inp) {
        if (_mr.injectingMovement || !_cfm(inp, _O.q + 4) || inp.add(_O.t).readU32() !== 2) return false;
        const g = _gmg();
        if (!_cfm(g, _O.f + 1) || !g.add(_O.d).readPointer().equals(mgr)) return false;
        if (g.add(_O.f).readU8() === 0) {
          _MS.battle = NULL2;
          _MS.battleClient = NULL2;
          return true;
        }
        _MS.checked++;
        const matched = _cis(inp, g, false) === inp.add(_O.q).readU32();
        if (matched) {
          _MS.matched++;
          _MS.battle = g;
          _MS.battleClient = g.add(_O.c).readPointer();
        } else {
          _MS.mismatched++;
          _MS.battle = NULL2;
          _MS.battleClient = NULL2;
        }
        return matched;
      }
      function _cma(game, x, y) {
        const b = game.add(_O.c).readPointer();
        if (!_cfm(b, 260)) throw new Error("v70 movement battle unavailable");
        const own = _mr.native.getOwnCharacter(b);
        if (!_cfm(own, 56)) throw new Error("v70 movement character unavailable");
        const dx = x - _mr.native.getX(own), dy = y - _mr.native.getY(own);
        if (dx === 0 && dy === 0) return 0;
        const angle = _mr.native.getDirectionAngle(dx | 0, dy | 0);
        if (angle < 0 || angle > 360) throw new Error("v70 movement angle outside its expected range");
        return angle;
      }
      function _smi(x, y) {
        if (!_connection.status().ready) return false;
        const bm = _gmg();
        if (bm.isNull()) return false;
        if (!_cfm(bm, _O.f + 1)) return false;
        if (bm.add(_O.f).readU8() !== 0 && (!_MS.battle.equals(bm) || !_MS.battleClient.equals(bm.add(_O.c).readPointer()))) {
          _MS.blockedSends++;
          return false;
        }
        const mgr = bm.add(_O.d).readPointer();
        if (mgr.isNull()) return false;
        let inp = NULL2, xferred = false;
        try {
          const angle = _cma(bm, x, y);
          inp = _mr.native.allocate(_O.u);
          if (inp.isNull()) return false;
          inp.writeByteArray(_ECI.buffer);
          _mr.native.constructClientInput(inp, 2);
          inp.add(_O.o).writeS32(x | 0);
          inp.add(_O.p).writeS32(y | 0);
          inp.add(_O.r).writeS32(angle);
          inp.add(_O.s).writeS32(600);
          _cis(inp, bm);
          _mr.injectingMovement = true;
          try {
            xferred = true;
            _mr.native.addInput(mgr, inp);
          } finally {
            _mr.injectingMovement = false;
          }
          return true;
        } catch (_) {
          return false;
        } finally {
          if (!xferred && !inp.isNull()) try {
            _N.az(inp);
          } catch (_) {
          }
        }
      }
      function _cfm(addr, size) {
        if (!addr || addr.isNull()) return false;
        const pa = Process.arch === "arm64" ? addr.and("0x00ffffffffffffff") : addr;
        const rng = Process.findRangeByAddress(pa);
        return rng !== null && rng.protection.includes("r") && pa.add(size).compare(rng.base.add(rng.size)) <= 0;
      }
      function _gpc() {
        const ch = _gmc(), b = _gmb();
        if (ch.isNull() || b.isNull()) return null;
        const tm = _mr.native.getTileMap(b);
        const out = _mr.pathOutput;
        if (!tm || tm.isNull() || !out || out.isNull()) return null;
        return { character: ch, tileMap: tm, output: out, outputY: out.add(4), pathfindingFlag: _mr.native.getPathfindingFlag(ch) & 1 };
      }
      function _oagmi(inp, now) {
        if (!_ag.enabled) return;
        _ag.manualUntil = now + 650;
        try {
          const own = _gmc();
          if (!own || own.isNull()) return;
          const x = inp.add(_O.o).readS32(), y = inp.add(_O.p).readS32();
          const ox = _mr.native.getX(own), oy = _mr.native.getY(own);
          if (Math.hypot(x - ox, y - oy) < 24) {
            _ag.manualUntil = now;
            _ag.lastCheckAt = 0;
            _ag.lastCarryCheckAt = 0;
            _ag.lastMoveAt = 0;
          }
        } catch (_) {
        }
      }
      function _fab(bmc, ox, oy, now) {
        if (now - _ag.lastBallScanAt < 200) return _ag.ball;
        _ag.lastBallScanAt = now;
        const snap = _gbs(bmc, now);
        if (snap === null) return null;
        let cl = null;
        for (const obj of snap.objects) {
          try {
            if (_got2(obj) !== 0) continue;
            const data = _N.bg(obj);
            if (!data || data.isNull()) continue;
            const key = data.toString();
            let isBall = _ag.ballDataNames.get(key);
            if (isBall === void 0) {
              const name = _rss(_N.bh(data), 96);
              isBall = name !== null && new RegExp(_d(_S.ball), "i").test(name);
              if (_ag.ballDataNames.size >= 64) _ag.ballDataNames.clear();
              _ag.ballDataNames.set(key, isBall);
            }
            if (!isBall) continue;
            const x = _N.be(obj), y = _N.bf(obj);
            const dsq = (x - ox) ** 2 + (y - oy) ** 2;
            if (!cl || dsq < cl.distanceSq) cl = { x, y, distanceSq: dsq };
          } catch (_) {
          }
        }
        _ag.ball = cl;
        return cl;
      }
      function _pan(open, node) {
        let i = open.length;
        open.push(node);
        while (i > 0) {
          const p = i - 1 >> 1;
          if (open[p].f <= node.f) break;
          open[i] = open[p];
          i = p;
        }
        open[i] = node;
      }
      function _pop(open) {
        const first = open[0], last = open.pop();
        if (open.length) {
          let i = 0;
          while (i * 2 + 1 < open.length) {
            let ch = i * 2 + 1;
            if (ch + 1 < open.length && open[ch + 1].f < open[ch].f) ch++;
            if (last.f <= open[ch].f) break;
            open[i] = open[ch];
            i = ch;
          }
          open[i] = last;
        }
        return first;
      }
      function _faw(fx, fy, tx, ty, now, pb = 40) {
        const ctx = _gpc();
        if (!ctx || !_ag.mapSize) return null;
        const { tileMap: tm, output: out, outputY: oy, pathfindingFlag: pf } = ctx;
        let pc = 0;
        const clr = (x1, y1, x2, y2) => {
          out.writeS32(-1);
          oy.writeS32(-1);
          pc++;
          _ag.routePathCalls++;
          return _mr.native.pathfind(Math.round(x1), Math.round(y1), Math.round(x2), Math.round(y2), tm, out, pf, 0, 0, 1) === 0;
        };
        if (clr(fx, fy, tx, ty)) {
          _ag.route = null;
          _ag.routeGoal = null;
          _ag.routePlan = null;
          _ag.routeFailureAt = 0;
          return { x: tx, y: ty };
        }
        const goal = _ag.routeGoal;
        const sg = goal && Math.hypot(goal[0] - tx, goal[1] - ty) < 300;
        if (sg && _ag.route) {
          const rt = _ag.route;
          while (rt.length > 1 && Math.hypot(rt[0].x - fx, rt[0].y - fy) < 160) rt.shift();
          if (rt.length === 1 && Math.hypot(rt[0].x - fx, rt[0].y - fy) < 80) {
            _ag.route = null;
          } else if (rt.length) {
            for (let i = rt.length - 1, ch = 0; i >= 0 && ch < 8; i--, ch++) {
              if (!clr(fx, fy, rt[i].x, rt[i].y)) continue;
              rt.splice(0, i);
              return rt[0];
            }
            if (rt.length > 8 && clr(fx, fy, rt[0].x, rt[0].y)) return rt[0];
            _ag.route = null;
            _ag.routePlan = null;
          }
        }
        const w = _ag.mapSize[0], h = _ag.mapSize[1];
        const heur = (x, y) => Math.hypot(tx - x, ty - y);
        let plan = _ag.routePlan;
        if (!plan || !sg || plan.width !== w || plan.height !== h || plan.tileMapKey !== tm.toString() || plan.pathfindingFlag !== pf || Math.hypot(plan.startX - fx, plan.startY - fy) > 600) {
          if (sg && _ag.routeFailureAt > 0 && now - _ag.routeFailureAt < 600 && !plan) return null;
          const ttx = Math.floor(fx / 300), tty = Math.floor(fy / 300);
          const start = { id: -1, x: fx, y: fy, tx: ttx, ty: tty, g: 0, f: heur(fx, fy), parent: null };
          plan = { width: w, height: h, tileMapKey: tm.toString(), pathfindingFlag: pf, startX: fx, startY: fy, start, nodes: /* @__PURE__ */ new Map([[-1, start]]), open: [start], closed: /* @__PURE__ */ new Set(), edges: /* @__PURE__ */ new Map(), current: null, finishIndex: 0, neighborIndex: 0, expanded: 0 };
          _ag.routePlan = plan;
          _ag.route = null;
          _ag.routeGoal = [tx, ty];
        }
        const ss = Date.now();
        const ba = () => pc < pb && Date.now() - ss < 2;
        const ec = (nd, ntx, nty) => {
          const id = ntx + nty * w;
          const key = nd.id < id ? nd.id + ":" + id : id + ":" + nd.id;
          if (plan.edges.has(key)) return plan.edges.get(key);
          if (!ba()) return null;
          const res = clr(nd.x, nd.y, ntx * 300 + 150, nty * 300 + 150);
          plan.edges.set(key, res);
          return res;
        };
        const dirs = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
        let found = null, exp = 0;
        srch: while ((plan.current || plan.open.length) && exp < 12 && ba() && plan.expanded < w * h) {
          if (!plan.current) {
            const nd2 = _pop(plan.open);
            if (plan.closed.has(nd2.id) || plan.nodes.get(nd2.id) !== nd2) continue;
            plan.closed.add(nd2.id);
            plan.expanded++;
            plan.current = nd2;
            plan.finishIndex = 0;
            plan.neighborIndex = 0;
          }
          const nd = plan.current;
          if (plan.finishIndex === 0) {
            if (Math.hypot(tx - nd.x, ty - nd.y) <= 750) {
              if (!ba()) break;
              if (clr(nd.x, nd.y, tx, ty)) {
                found = nd;
                break;
              }
            }
            plan.finishIndex = 1;
          }
          while (plan.neighborIndex < dirs.length) {
            const [dx, dy] = dirs[plan.neighborIndex];
            const ntx = nd.tx + dx, nty = nd.ty + dy, id = ntx + nty * w;
            if (ntx < 1 || nty < 1 || ntx >= w - 1 || nty >= h - 1 || plan.closed.has(id)) {
              plan.neighborIndex++;
              continue;
            }
            const nx = ntx * 300 + 150, ny = nty * 300 + 150;
            const g = nd.g + Math.hypot(nx - nd.x, ny - nd.y);
            const prev = plan.nodes.get(id);
            if (prev && prev.g <= g) {
              plan.neighborIndex++;
              continue;
            }
            if (dx && dy) {
              const hz = ec(nd, ntx, nd.ty);
              if (hz === null) break srch;
              if (!hz) {
                plan.neighborIndex++;
                continue;
              }
              const vt = ec(nd, nd.tx, nty);
              if (vt === null) break srch;
              if (!vt) {
                plan.neighborIndex++;
                continue;
              }
            }
            const rch = ec(nd, ntx, nty);
            if (rch === null) break srch;
            plan.neighborIndex++;
            if (!rch) continue;
            const nxt = { id, x: nx, y: ny, tx: ntx, ty: nty, g, f: g + heur(nx, ny), parent: nd };
            plan.nodes.set(id, nxt);
            _pan(plan.open, nxt);
          }
          plan.current = null;
          exp++;
        }
        if (!found) {
          if (!plan.current && !plan.open.length || plan.expanded >= w * h) {
            _ag.routePlan = null;
            _ag.routeFailureAt = now;
          }
          return null;
        }
        const route = [{ x: tx, y: ty }];
        for (let nd = found; nd && nd !== plan.start; nd = nd.parent) route.unshift({ x: nd.x, y: nd.y });
        _ag.routePlan = null;
        if (!route.length) return null;
        let wp = null;
        for (let i = route.length - 1; i >= 0 && pc < pb; i--) {
          if (clr(fx, fy, route[i].x, route[i].y)) {
            route.splice(0, i);
            wp = route[0];
            break;
          }
        }
        _ag.route = route;
        return wp;
      }
      function _mat(bmc, ox, oy, tx, ty, now) {
        if (now < _ag.manualUntil) {
          _ag.lastWaitReason = "manualMovement";
          return false;
        }
        if (now - _ag.lastMoveAt < 140) {
          _ag.lastWaitReason = "moveInterval";
          return false;
        }
        if (!_mr.bound) {
          _ag.lastWaitReason = "movementGuard";
          return false;
        }
        const cb = _gmb();
        if (cb.isNull() || !cb.equals(bmc)) return false;
        const tgt = _faw(ox, oy, Math.round(tx), Math.round(ty), now);
        if (!tgt) {
          _ag.lastWaitReason = _ag.routePlan ? "routePlanning" : "noRoute";
          return false;
        }
        if (Math.hypot(tgt.x - ox, tgt.y - oy) < 80) {
          _ag.lastWaitReason = "atWaypoint";
          return false;
        }
        if (!_smi(tgt.x, tgt.y)) {
          _ag.lastWaitReason = "inputRejected";
          return false;
        }
        _mr.native.setPredictionPosition(bmc, tgt.x, tgt.y, 1);
        _ag.lastWaitReason = null;
        _ag.lastMoveAt = now;
        _ag.moveTarget = [tgt.x, tgt.y];
        return true;
      }
      function _sam(bmc, ox, oy, now) {
        if (_ag.moveTarget === null || now < _ag.manualUntil) return;
        const cb = _gmb();
        if (cb.isNull() || !cb.equals(bmc)) return;
        _mr.native.setPredictionPosition(bmc, ox, oy, 1);
        _smi(ox, oy);
        _ag.moveTarget = null;
      }
      function _pagpr(ball, gx, gy, now, pb) {
        let pu = _ag.pickupRoute;
        if (!pu || Math.hypot(pu.x - ball.x, pu.y - ball.y) > 120 || pu.goalX !== gx || pu.goalY !== gy) {
          pu = { x: ball.x, y: ball.y, goalX: gx, goalY: gy, at: now, route: null, routeGoal: null, routePlan: null, routeFailureAt: 0 };
          _ag.pickupRoute = pu;
        }
        const active = [_ag.route, _ag.routeGoal, _ag.routePlan, _ag.routeFailureAt];
        try {
          _ag.route = pu.route;
          _ag.routeGoal = pu.routeGoal;
          _ag.routePlan = pu.routePlan;
          _ag.routeFailureAt = pu.routeFailureAt;
          _faw(pu.x, pu.y, gx, gy, now, pb);
          pu.at = now;
        } finally {
          pu.route = _ag.route;
          pu.routeGoal = _ag.routeGoal;
          pu.routePlan = _ag.routePlan;
          pu.routeFailureAt = _ag.routeFailureAt;
          [_ag.route, _ag.routeGoal, _ag.routePlan, _ag.routeFailureAt] = active;
        }
      }
      function _uag(bmc, now) {
        if (_ag.enabled && (!_panelForeground || _panelTime()-_panelLastTick>3000 || _st.requested === false || !_license.isActive())) {
          _ag.enabled = false; _ag.stopPending = true; _st.requested = false;
        }
        if (!_ag.enabled) {
          if (_ag.stopPending) {
            _ag.stopPending = false;
            try {
              const own = _goc(bmc);
              if (own && !own.isNull() && _mr.native && _ilc(own)) _sam(bmc, _mr.native.getX(own), _mr.native.getY(own), now);
            } catch (_) {
            }
          }
          return;
        }
        if (_ag.battle.isNull() || !_ag.battle.equals(bmc)) {
          _ag.battle = ptr(bmc.toString());
          _ag.lastCheckAt = 0;
          _ag.lastCarryCheckAt = 0;
          _ag.carriedKey = null;
          _ag.pickupRoute = null;
          _ag.lastWaitReason = null;
          _ag.lastMoveAt = 0;
          _ag.lastBallScanAt = 0;
          _ag.ball = null;
          _ag.moveTarget = null;
          _ag.route = null;
          _ag.routeGoal = null;
          _ag.routePlan = null;
          _ag.routeFailureAt = 0;
          _ag.mapSize = null;
          _ag.goal = null;
        }
        if (now - _ag.lastCarryCheckAt < 16) return;
        _ag.lastCarryCheckAt = now;
        try {
          if (!_mr.native || !_cfm(bmc, 256)) {
            _ag.lastWaitReason = "battleContext";
            return;
          }
          const own = _goc(bmc);
          if (!own || own.isNull() || !_ilc(own)) return;
          const carried = _N.bi(own, bmc);
          const ck = carried && !carried.isNull() ? carried.toString() : null;
          const oc = ck !== _ag.carriedKey;
          if (!oc && now - _ag.lastCheckAt < 80) return;
          _ag.carriedKey = ck;
          _ag.lastCheckAt = now;
          if (oc) {
            _ag.lastMoveAt = 0;
            _ag.route = null;
            _ag.routeGoal = null;
            _ag.routePlan = null;
            _ag.routeFailureAt = 0;
            _ag.lastBallScanAt = 0;
          }
          const x = _mr.native.getX(own), y = _mr.native.getY(own);
          const tm = _mr.native.getTileMap(bmc);
          if (!_cfm(tm, _O.l + 4)) return;
          const w = tm.add(_O.k).readU32(), h = tm.add(_O.l).readU32();
          _ag.mapSize = [w, h];
          if (w < 15 || w > 80 || h < 15 || h > 80 || x < 0 || y < 0 || x >= w * 300 || y >= h * 300) return;
          const team = _mr.native.getOwnPlayerTeam(bmc);
          if (team !== 0 && team !== 1) return;
          if (!carried || carried.isNull()) {
            if (oc) _ag.pickupRoute = null;
            if (_ag.phase !== "findBall") {
              _ag.route = null;
              _ag.routeGoal = null;
              _ag.routePlan = null;
            }
            _ag.phase = "findBall";
            _ag.linkedBallName = null;
            const ball = _fab(bmc, x, y, now);
            if (ball) {
              const dsq = (ball.x - x) ** 2 + (ball.y - y) ** 2;
              const pbc = _ag.routePathCalls;
              if (dsq > 140 * 140) _mat(bmc, x, y, ball.x, ball.y, now);
              const rb = 40 - (_ag.routePathCalls - pbc);
              if (dsq <= 900 * 900 && rb >= 24 && !_ag.routePlan) {
                _pagpr(ball, Math.floor(w / 2) * 300 + 150, team === 1 ? (h - 2) * 300 + 150 : 450, now, rb);
              }
            }
            return;
          }
          _ag.ball = null;
          const cd = _mr.native.getGameObjectData(carried);
          if (!cd || cd.isNull()) return;
          const cn = _rss(_N.bh(cd), 96);
          _ag.linkedBallName = cn;
          if (!cn || !new RegExp(_d(_S.ball), "i").test(cn)) return;
          if (_ag.phase === "findBall") {
            _ag.route = null;
            _ag.routeGoal = null;
            _ag.routePlan = null;
          }
          const gy = team === 1 ? (h - 2) * 300 + 150 : 450;
          const cx = Math.floor(w / 2) * 300 + 150;
          const pu = _ag.pickupRoute;
          if (pu) {
            if (now - pu.at <= 1200 && Math.hypot(pu.x - x, pu.y - y) <= 600 && pu.goalX === cx && pu.goalY === gy && (pu.route || pu.routePlan)) {
              _ag.route = pu.route;
              _ag.routeGoal = pu.routeGoal;
              _ag.routePlan = pu.routePlan;
              _ag.routeFailureAt = 0;
            }
            _ag.pickupRoute = null;
          }
          _ag.phase = "dribble";
          _ag.goal = [cx, gy];
          _mat(bmc, x, y, cx, gy, now);
        } catch (error) {
          _ag.lastError = String(error);
        }
      }
      function _goc(battle) {
        return _N.bj(battle);
      }
      function _vb(mod) {
        try {
          if (Process.arch !== "arm64" || mod.size < 22407156) return false;
          const bytes = mod.base.add(22407136).readByteArray(20);
          if (bytes === null || Array.from(new Uint8Array(bytes), (b) => b.toString(16).padStart(2, "0")).join("") !== BUILD_ID) return false;
          return _irisCompatibleWords(mod);
        } catch (_) {
          return false;
        }
      }
      function _rs() {
        try {
          const hld = _lg.base.add(_O.b).readPointer();
          if (!_cfm(hld, Process.pointerSize)) return NULL2;
          const stage = hld.readPointer();
          return _cfm(stage, _O.a + 4) ? stage : NULL2;
        } catch (_) {
          return NULL2;
        }
      }
      function _lu() {
        try {
          return !_st.button.isNull() && _cfm(_st.button, 8) && _st.button.readPointer().equals(_lg.base.add(_O.ax)) && _cfm(_st.buttonText, 8) && _cfm(_st.labelClip, 8) && _cfm(_st.labelText, 8);
        } catch (_) {
          return false;
        }
      }
      function _fu() {
        _st.button = _st.buttonClip = _st.buttonText = _st.labelClip = _st.labelContainer = _st.labelText = NULL2;
        _st.labelStyleDirty = true;
        _st.stage = NULL2;
        _st.nextUiTryAt = Date.now() + 500;
      }
      function _wuo(obj) {
        const vt = obj.readPointer();
        for (const slot of [0, 8]) {
          const addr = vt.add(slot).readPointer(), key = addr.toString();
          if (_st.destructorHooks.has(key)) continue;
          const rng = Process.findRangeByAddress(addr);
          if (!rng || !rng.protection.includes("x")) throw Error("native UI destructor unavailable");
          _st.destructorHooks.add(key);
          _st.hooks.push(Interceptor.attach(addr, { onEnter(args) {
            if (args[0].equals(_st.button) || args[0].equals(_st.labelClip) || args[0].equals(_st.buttonClip)) _fu();
          } }));
        }
      }
      const _UI = {
        label: _d(_S.uiLabel),
        bOff: _d(_S.uiBOff),
        bOn: _d(_S.uiBOn),
        startup: _d(_S.uiStartup),
        onMsg: _d(_S.uiOnMsg),
        offMsg: _d(_S.uiOffMsg),
        btnOnColor: 4278255360,
        btnOffColor: 4294901760,
        labelRight: 320,
        labelY: 85,
        btnRight: 290,
        btnY: 160
      };
      const _ls = { fontSize: 24, scale: 1, gradientEnabled: true, gradientStart: _d(_S.gS), gradientMiddle: _d(_S.gM), gradientEnd: _d(_S.gE) };
      function _sbc() {
        if (!_lu()) return;
        _wns(_ag.enabled ? _UI.bOn : _UI.bOff, (text) => _N.ar(_st.buttonText, text));
        _N.as(_st.buttonText, _ag.enabled ? _UI.btnOnColor : _UI.btnOffColor);
      }
      function _nls(patch, cur) {
        if (!patch || typeof patch !== "object" || Array.isArray(patch)) throw Error("label style must be an object");
        const res = { ...cur };
        const keys = [_d(_S.lsFs), _d(_S.lsSc), _d(_S.lsGE), _d(_S.lsGS), _d(_S.lsGM), _d(_S.lsGEn)];
        for (const key of Object.keys(patch)) {
          if (!keys.includes(key)) throw Error("unknown label setting: " + key);
          const val = patch[key];
          if (key === _d(_S.lsFs)) {
            if (!Number.isInteger(val) || val < 8 || val > 96) throw Error("fontSize: integer 8..96");
          } else if (key === _d(_S.lsSc)) {
            if (typeof val !== "number" || !Number.isFinite(val) || val < 0.25 || val > 4) throw Error("scale: 0.25..4");
          } else if (key === _d(_S.lsGE)) {
            if (typeof val !== "boolean") throw Error("gradientEnabled: true/false");
          } else {
            if (key === _d(_S.lsGM) && val === null) {
              res[key] = null;
              continue;
            }
            if (typeof val !== "string" || !/^#[0-9a-fA-F]{6}$/.test(val)) throw Error(key + ": #RRGGBB");
            res[key] = val.toUpperCase();
            continue;
          }
          res[key] = val;
        }
        return res;
      }
      function _fgl(text, style) {
        if (!style.gradientEnabled) return String(text);
        const stops = [style.gradientStart, ...style.gradientMiddle === null ? [] : [style.gradientMiddle], style.gradientEnd].map((hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)));
        const chars = Array.from(String(text));
        let res = "";
        for (let i = 0; i < chars.length; i++) {
          const pos = (chars.length > 1 ? i / (chars.length - 1) : 0) * (stops.length - 1);
          const seg = Math.min(stops.length - 2, Math.floor(pos)), fr = pos - seg;
          const rgb = stops[seg].map((v, c) => Math.round(v + (stops[seg + 1][c] - v) * fr).toString(16).padStart(2, "0")).join("");
          res += "<c" + rgb + ">" + chars[i];
        }
        return res + "</c>";
      }
      function _als() {
        if (!_lu()) return;
        _wns(_fgl(_UI.label, _ls), (text) => _N.ar(_st.labelText, text));
        _N.at(_st.labelText, _ls.fontSize);
        _N.as(_st.labelText, 0);
        _N.am(_st.labelClip, _ls.scale);
        _st.labelStyleDirty = false;
      }
      function _arls() {
        if (_st.pendingLabelStyle !== null) {
          Object.assign(_ls, _st.pendingLabelStyle);
          _st.pendingLabelStyle = null;
          _st.labelStyleDirty = true;
        }
        if (_st.labelStyleDirty) _als();
      }
      function _enu(now) {} // UI is owned by PanelHost on Android main thread.
// Pure engine state commit: shared by the UI scheduler and the game update hook.
// No Android API, native HUD allocation or game input is invoked here.
function _art() {
  if (!_license.isActive() && (_ag.enabled || _st.requested === true)) _st.requested = false;
  if (_st.requested === null) return;
  _ag.enabled = !!_st.requested;
  _st.requested = null;
  _ag.stopPending = !_ag.enabled;
  _ag.lastCheckAt = _ag.lastCarryCheckAt = _ag.lastMoveAt = 0;
  _ag.carriedKey = _ag.pickupRoute = _ag.ball = null;
  _ag.route = _ag.routeGoal = _ag.routePlan = null;
  _ag.routeFailureAt = 0;
  _ag.lastWaitReason = _ag.lastError = null;
  if (_ag.enabled) _ag.moveTarget = null;
  _ag.phase = _ag.enabled ? 'findBall' : 'idle';
}

      function _ih() {
        const att = (off, cb) => _st.hooks.push(Interceptor.attach(_lg.base.add(off), cb));
        att(_O.ai, { onEnter(args) {
          const now = Date.now();
          if (!_st.disposed && args[0].equals(_st.button) && now - _st.lastPressAt >= 200) {
            _st.lastPressAt = now;
            _license.press();
          }
        } });
        att(_O.w, { onEnter(args) {
          if (_st.disposed || _mr.injectingMovement) return;
          try {
            if (_cfm(args[1], _O.u) && args[1].add(_O.t).readU32() === 2) {
              _ons(args[0], args[1]);
              _oagmi(args[1], Date.now());
            }
          } catch (err) {
            _st.error = String(err);
          }
        } });
        att(_O.ae, { onEnter(args) {
          if (_st.disposed || !args[0] || args[0].isNull()) return;
          _mr.battleModeClient = args[0];
          try { _art(); if (_connectionBeforeTick(args[0])) _uag(args[0], Date.now()); }
          catch (error) { _connection.hold("context"); _connectionPrune(); _ag.lastError=String(error); }
        } });
        att(_O.ad, { onLeave() {
          if (_st.disposed) return;
          try {
            _art();
            _arls();
            const now = Date.now();
            if (now - _st.lastContextCheckAt >= 250) {
              _st.lastContextCheckAt = now;
              const g = _gmg();
              const b = _cfm(g, _O.c + 8) ? g.add(_O.c).readPointer() : NULL2;
              if (b.isNull()) {
                _mr.battleModeClient = NULL2;
                _bs.snapshot = null;
                _MS.battle = _MS.battleClient = NULL2;
                _connection.clear(); _connectionPrune();
              }
            }
            _enu(now);
          } catch (err) {
            _st.uiError = String(err);
          }
        } });
      }
      function _start(mod) {
        if (!_vb(mod)) {
          _st.error = _d(_S.bErr);
          console.log(_d(_S.aLog) + _st.error);
          return;
        }
        _lg = mod;
        try {
          _N = Object.freeze({
            ay: new NativeFunction(_lg.base.add(_O.ay), "pointer", []),
            az: new NativeFunction(_lg.base.add(_O.az), "void", ["pointer"]),
            ba: new NativeFunction(_lg.base.add(_O.ba), "pointer", []),
            bb: new NativeFunction(_lg.base.add(_O.bb), "void", ["pointer", "pointer", "uint", "int", "float"]),
            bc: new NativeFunction(_lg.base.add(_O.bc), "void", ["pointer", "pointer"]),
            bd: new NativeFunction(_lg.base.add(_O.bd), "void", ["pointer"]),
            be: new NativeFunction(_lg.base.add(_O.be), "int", ["pointer"]),
            bf: new NativeFunction(_lg.base.add(_O.bf), "int", ["pointer"]),
            bg: new NativeFunction(_lg.base.add(_O.bg), "pointer", ["pointer"]),
            bh: new NativeFunction(_lg.base.add(_O.bh), "pointer", ["pointer"]),
            bi: new NativeFunction(_lg.base.add(_O.bi), "pointer", ["pointer", "pointer"]),
            bj: new NativeFunction(_lg.base.add(_O.bj), "pointer", ["pointer"]),
            bk: new NativeFunction(_lg.base.add(_O.bk), "pointer", ["ulong"]),
            af: new NativeFunction(_lg.base.add(_O.af), "void", ["pointer", "pointer", "pointer"]),
            ag: new NativeFunction(_lg.base.add(_O.ag), "void", ["pointer"]),
            ah: new NativeFunction(_lg.base.add(_O.ah), "void", ["pointer", "pointer", "int"]),
            aj: new NativeFunction(_lg.base.add(_O.aj), "pointer", ["pointer", "pointer"]),
            ak: new NativeFunction(_lg.base.add(_O.ak), "void", ["pointer", "pointer"]),
            al: new NativeFunction(_lg.base.add(_O.al), "void", ["pointer", "float", "float"]),
            am: new NativeFunction(_lg.base.add(_O.am), "void", ["pointer", "float"]),
            an: new NativeFunction(_lg.base.add(_O.an), "void", ["pointer"]),
            ao: new NativeFunction(_lg.base.add(_O.ao), "pointer", ["pointer", "pointer"]),
            ap: new NativeFunction(_lg.base.add(_O.ap), "void", ["pointer", "int"]),
            aq: new NativeFunction(_lg.base.add(_O.aq), "void", ["pointer", "int"]),
            ar: new NativeFunction(_lg.base.add(_O.ar), "void", ["pointer", "pointer"]),
            as: new NativeFunction(_lg.base.add(_O.as), "void", ["pointer", "uint"]),
            at: new NativeFunction(_lg.base.add(_O.at), "void", ["pointer", "int"])
          });
          if (!_bmr()) throw Error("movement bindings unavailable");
          _ih();
          _st.started = true;
        } catch (err) {
          _st.error = String(err);
          for (const h of _st.hooks) h.detach();
          _st.hooks.length = 0;
          console.log(_d(_S.aLog) + _st.error);
        }
      }
// BRF installs its native hooks first. Iris then attaches to the final targets.
function _irisCompatibleWords(mod) {
  if(_NW.every(([off,word])=>mod.base.add(off).readU32()===word))return true;
  // The original memory build-ID check remains mandatory in _vb. Only the
  // installed verifier's exact SHA-256 match permits BRF-modified prologues.
  return _features.ready && !!(globalThis.__irisBoot && globalThis.__irisBoot.gameFileVerified===true);
}
const _wsa = Date.now();
function _wfl() {
  if (_st.disposed) return;
  const mod=[_d(_S.libg),_d(_S.libs),_d(_S.libbw)].map(n=>Process.findModuleByName(n)).find(Boolean);
  if(mod && (_features.ready || _features.error)){_start(mod);return;}
  if(Date.now()-_wsa>=60000){
    _st.error=mod?'native feature initialization timed out':'game library not found';return;
  }
  setTimeout(_wfl,100);
}

      globalThis.setHxptAutoGoalEnabled = function(en) {
        if (!_st.started || _st.disposed) return false;
        if (en && !_license.isActive()) return false;
        _st.requested = !!en;
        return true;
      };
      globalThis.setHxptLabelStyle = function(patch) {
        if (!_st.started || _st.disposed) return { accepted: false, error: "script not ready" };
        try {
          _st.pendingLabelStyle = _nls(patch, _st.pendingLabelStyle || _ls);
          return { accepted: true, style: { ..._st.pendingLabelStyle } };
        } catch (err) {
          return { accepted: false, error: String(err) };
        }
      };
      globalThis.setHxptLabelSize = function(fs, sc) {
        return globalThis.setHxptLabelStyle({ fontSize: fs, ...sc === void 0 ? {} : { scale: sc } });
      };
      globalThis.setHxptLabelGradient = function(start, mid, end) {
        return globalThis.setHxptLabelStyle({
          gradientEnabled: true,
          gradientStart: start,
          gradientMiddle: end === void 0 ? null : mid,
          gradientEnd: end === void 0 ? mid : end
        });
      };
      _wfl();
    })();
  }
});
export default require_agent();

import unittest
from unittest.mock import Mock,patch
import cv2
from round_start import RoundStartTracker
from brawl_ball import own_goal_exit,path_waypoint
from tests.iris_input_support import controller

class RoundStartTests(unittest.TestCase):
    player=[1014,349,1200,574]
    peers=[[720,349,880,574],[880,349,1040,574]]

    def test_first_frame_does_not_need_damage_or_enemy(self):
        t=RoundStartTracker()
        self.assertEqual(t.update(self.player,[],1920,1080,1),'player appeared')
        self.assertIsNone(t.update(self.player,[],1920,1080,1.1))

    def test_goal_reset_is_detected_while_state_remains_match(self):
        t=RoundStartTracker()
        t.update(self.player,self.peers,1920,1080,1)
        for n in range(11,41):t.update(self.player,[],1920,1080,n/10)
        self.assertEqual(t.update(self.player,self.peers,1920,1080,4.1),'kickoff lineup')
        self.assertIsNone(t.update(self.player,self.peers,1920,1080,4.2))

    def test_respawn_and_teleport_request_fresh_input(self):
        t=RoundStartTracker(); t.update(self.player,[],1920,1080,1)
        self.assertEqual(t.update(self.player,[],1920,1080,3),'player appeared')
        for n in range(31,51):t.update(self.player,[],1920,1080,n/10)
        self.assertEqual(t.update([200,349,400,574],[],1920,1080,5.1),'spawn position changed')

    def test_midfield_teammate_lineup_does_not_reset_ball_possession(self):
        t=RoundStartTracker()
        t.update(self.player,[],1920,1080,1,kickoff_context=False)
        for n in range(11,41):t.update(self.player,[],1920,1080,n/10,kickoff_context=False)
        self.assertIsNone(t.update(self.player,self.peers,1920,1080,4.1,kickoff_context=False))

    def test_leaving_intro_rearms_on_next_player_frame(self):
        t=RoundStartTracker();t.update(self.player,[],1920,1080,1)
        t.leave_match()
        self.assertEqual(t.update(self.player,[],1920,1080,3),'player appeared')

    def test_down_settles_before_move_and_round_retries_shortly(self):
        c=controller();events=[]
        c.touch_down=Mock(side_effect=lambda *a,**k:events.append('down') or True)
        c.touch_move=Mock(side_effect=lambda *a,**k:events.append('move') or True)
        c.touch_up=Mock(return_value=True)
        with patch('window_controller.time.monotonic',return_value=10),patch('window_controller.time.sleep',side_effect=lambda x:events.append(('settle',x))):
            c.rearm_movement_for_round();c.move(0,-75)
        self.assertEqual(events,['down',('settle',.025),'move'])
        with patch('window_controller.time.monotonic',return_value=10.3),patch('window_controller.time.sleep'):
            c.move(0,-75)
        self.assertEqual(c.touch_down.call_count,2)
        c.touch_up.assert_called_once()
        with patch('window_controller.time.monotonic',return_value=12),patch('window_controller.time.sleep'):
            c.move(0,-75)
        self.assertEqual(c.touch_down.call_count,2)

    def test_recorded_spawn_moves_left_to_goal_opening(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/blocked_spawn.jpg'),cv2.COLOR_BGR2RGB)
        target=own_goal_exit(frame,(595,329))
        self.assertIsNotNone(target)
        self.assertLess(target[0],510)
        self.assertEqual(target[1],329)
        waypoint=path_waypoint((595,329),target,[(536,244,573,292)])
        self.assertLess(waypoint[0],595)

    def test_goal_exit_does_not_override_player_in_front_of_goal(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/blocked_spawn.jpg'),cv2.COLOR_BGR2RGB)
        self.assertIsNone(own_goal_exit(frame,(480,180)))

if __name__=='__main__':unittest.main()

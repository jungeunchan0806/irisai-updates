import json
from pathlib import Path
import subprocess
import sys
import pytest
from pyla_addons import updater

def manifest(files, old=None):
    return {"schema": 1, "platform": "windows", "product": "pyla-windows", "version": "1.0.0", "files": [
        {"path": name, "sha256": updater.digest(data), "size": len(data),
         "base_sha256": updater.digest(old[name]) if old and name in old else None}
        for name, data in files.items()]}


def test_update_preserves_settings_and_is_repeatable(tmp_path):
    (tmp_path / "main.py").write_bytes(b"old")
    (tmp_path / "cfg").mkdir()
    (tmp_path / "cfg" / "user.toml").write_bytes(b"personal=true")
    payload = {"main.py": b"new", "pyla_addons/new.py": b"pass"}
    spec = manifest(payload, {"main.py": b"old"})
    assert updater.install(tmp_path, spec, payload)
    assert not updater.install(tmp_path, spec, payload)
    assert (tmp_path / "cfg" / "user.toml").read_bytes() == b"personal=true"
    assert (tmp_path / "main.py").read_bytes() == b"new"
    assert len(list((tmp_path / ".pyla-backups").glob("*/main.py"))) == 1


def test_update_records_matching_existing_install(tmp_path):
    (tmp_path / "main.py").write_bytes(b"already")
    payload = {"main.py": b"already"}
    assert not updater.install(tmp_path, manifest(payload), payload)
    assert json.loads((tmp_path / updater.STATE).read_text())["files"]["main.py"] == updater.digest(b"already")


def test_conflict_and_hash_mismatch_do_not_write(tmp_path):
    (tmp_path / "main.py").write_bytes(b"local edits")
    payload = {"main.py": b"new", "play.py": b"new play"}
    with pytest.raises(RuntimeError, match="Local changes"):
        updater.install(tmp_path, manifest(payload, {"main.py": b"old"}), payload)
    assert not (tmp_path / "play.py").exists()
    with pytest.raises(ValueError, match="hash verification"):
        updater.install(tmp_path, manifest(payload), {"main.py": b"tampered"})
    assert (tmp_path / "main.py").read_bytes() == b"local edits"


def test_transaction_rolls_back_on_failed_write(tmp_path, monkeypatch):
    (tmp_path / "main.py").write_bytes(b"old")
    payload = {"main.py": b"new", "play.py": b"new play"}
    real = updater.atomic_write
    def fail(path, data):
        if path.name == "play.py":
            raise OSError("disk full")
        real(path, data)
    monkeypatch.setattr(updater, "atomic_write", fail)
    with pytest.raises(OSError, match="disk full"):
        updater.install(tmp_path, manifest(payload, {"main.py": b"old"}), payload)
    assert (tmp_path / "main.py").read_bytes() == b"old"
    assert not (tmp_path / ".pyla-update-journal.json").exists()


def test_interrupted_transaction_recovers(tmp_path):
    backup = tmp_path / ".pyla-backups" / "1"
    backup.mkdir(parents=True)
    (backup / "main.py").write_bytes(b"original")
    (tmp_path / "main.py").write_bytes(b"partial")
    (tmp_path / "play.py").write_bytes(b"created")
    (tmp_path / ".pyla-update-journal.json").write_text(json.dumps({
        "backup": ".pyla-backups/1", "files": [{"path": "main.py", "existed": True},
                                               {"path": "play.py", "existed": False}]}))
    assert updater.recover(tmp_path)
    assert (tmp_path / "main.py").read_bytes() == b"original"
    assert not (tmp_path / "play.py").exists()


@pytest.mark.parametrize("name", ["../main.py", "cfg/general_config.toml", "/main.py", "C:/main.py",
                                 "pyla_addons/../../main.py", "pyla_addons\\evil.py", "pyla_addons/x.exe"])
def test_patch_path_restrictions(tmp_path, name):
    with pytest.raises(ValueError):
        updater.safe_target(tmp_path, name)


def test_lock_excludes_other_process(tmp_path):
    code = "from pathlib import Path; from pyla_addons.updater import app_lock; "
    code += f"\nwith app_lock(Path({str(tmp_path)!r})): pass"
    with updater.app_lock(tmp_path):
        child = subprocess.run([sys.executable, "-c", code], capture_output=True)
    assert child.returncode != 0 and b"running" in child.stderr
    with updater.app_lock(tmp_path):
        pass


def test_crlf_source_is_not_a_local_edit(tmp_path):
    (tmp_path / "main.py").write_bytes(b"old\r\n")
    payload = {"main.py": b"new\n"}
    assert updater.install(tmp_path, manifest(payload, {"main.py": b"old\n"}), payload)


def test_symlink_and_non_https_updates_rejected(tmp_path):
    outside = tmp_path.parent / (tmp_path.name + "-outside")
    outside.mkdir()
    (tmp_path / "pyla_addons").symlink_to(outside, target_is_directory=True)
    with pytest.raises(ValueError, match="symlink"):
        updater.safe_target(tmp_path, "pyla_addons/bad.py")
    with pytest.raises(ValueError, match="HTTPS"):
        updater.fetch("http://example.com/manifest.json", 100)


def test_https_feed_installs_then_updates_using_saved_baseline(tmp_path, monkeypatch):
    payload = {"main.py": b"first"}
    first = manifest(payload)
    first["files"][0]["url"] = "https://updates.example/main.py"
    responses = {"https://updates.example/manifest.json": json.dumps(first).encode(),
                 "https://updates.example/main.py": b"first"}
    monkeypatch.setattr(updater, "fetch", lambda url, limit: responses[url])
    assert updater.check_and_update(tmp_path, "https://updates.example/manifest.json")
    second = manifest({"main.py": b"second"})
    second["version"] = "1.0.1"
    second["files"][0]["url"] = "https://updates.example/main.py"
    responses["https://updates.example/manifest.json"] = json.dumps(second).encode()
    responses["https://updates.example/main.py"] = b"second"
    assert updater.check_and_update(tmp_path, "https://updates.example/manifest.json")
    assert (tmp_path / "main.py").read_bytes() == b"second"


def test_different_update_host_is_rejected(tmp_path, monkeypatch):
    spec = manifest({"main.py": b"x"})
    spec["files"][0]["url"] = "https://other.example/main.py"
    monkeypatch.setattr(updater, "fetch", lambda url, limit: json.dumps(spec).encode())
    with pytest.raises(ValueError, match="configured update host"):
        updater.check_and_update(tmp_path, "https://updates.example/manifest.json")


def test_mac_or_unknown_feed_is_rejected_before_files_change(tmp_path):
    spec = manifest({'main.py': b'x'})
    spec['platform'] = 'macos'
    with pytest.raises(ValueError, match='Windows'):
        updater.install(tmp_path, spec, {'main.py': b'x'})
    assert not (tmp_path / 'main.py').exists()


def test_iris_assets_are_patchable_but_user_models_are_not(tmp_path):
    assert updater.safe_target(tmp_path, 'images/brawl_ball/score_icon.png') == tmp_path / 'images/brawl_ball/score_icon.png'
    assert updater.safe_target(tmp_path, 'playstyles/iris_lane_up.pyla') == tmp_path / 'playstyles/iris_lane_up.pyla'
    with pytest.raises(ValueError): updater.safe_target(tmp_path, 'models/mainInGameModel.onnx')
    with pytest.raises(ValueError): updater.safe_target(tmp_path, 'playstyles/my_custom_style.pyla')


def test_older_published_version_cannot_downgrade(tmp_path):
    spec = manifest({'main.py': b'installed'})
    updater.install(tmp_path, spec, {'main.py': b'installed'})
    older = manifest({'main.py': b'old'})
    older['version'] = '0.9.0'
    with pytest.raises(RuntimeError, match='older'):
        updater.install(tmp_path, older, {'main.py': b'old'})
    assert (tmp_path / 'main.py').read_bytes() == b'installed'

from unittest.mock import Mock
import pytest
from webui.services import WebDataService


def service():
    svc = WebDataService.__new__(WebDataService)
    store = {'cfg/general_config.toml': {}, 'cfg/bot_config.toml': {}}
    svc._load_config = lambda path: dict(store[path])
    svc._save_config = lambda path, data: store.__setitem__(path, dict(data))
    return svc, store


def test_goal_and_windows_settings_survive_the_settings_api_service():
    svc, store = service()
    assert svc.update_settings('bot', {'auto_goal': True})['auto_goal'] is True
    result = svc.update_settings('general', {'emulator_port': 0, 'emulator_path': 'D:\\에뮬레이터 폴더\\HD-Player.exe',
                                              'emulator_instance': 'Pie64', 'emulator_boot_timeout': 180,
                                              'auto_emulator': True, 'auto_start_game': False})
    assert result['emulator_instance'] == 'Pie64'
    assert result['auto_start_game'] is False
    assert store['cfg/bot_config.toml']['auto_goal'] is True


def test_invalid_emulator_settings_are_rejected_before_save():
    svc, store = service()
    with pytest.raises(ValueError): svc.update_settings('general', {'emulator_port': 70000})
    assert store['cfg/general_config.toml'] == {}
    with pytest.raises(ValueError): svc.update_settings('general', {'emulator_boot_timeout': 0})
    assert store['cfg/general_config.toml'] == {}

import threading
from unittest.mock import Mock
from window_controller import WindowController

def controller():
    value = WindowController.__new__(WindowController)
    value._move_lock = threading.RLock()
    value.frame_lock = threading.Lock()
    value.width, value.height = 1920, 1080
    value.width_ratio = value.height_ratio = 1.0
    value.joystick_x, value.joystick_y = 220, 870
    value.PID_JOYSTICK, value.PID_ATTACK = 1, 2
    value.are_we_moving = False
    value.last_joystick_pos = (None, None)
    value._last_joystick_press = 0.0
    value._last_movement_log_time = 0.0
    value.re_apply_movement = False
    value.scrcpy_client = Mock(resolution=(1920, 1080))
    value.reconnect_scrcpy = Mock(return_value=False)
    return value

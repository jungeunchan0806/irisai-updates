from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import ast
import json
import pytest
from pyla_addons import emulators as e


def device(serial, ready=True):
    return SimpleNamespace(serial=serial, get_state=lambda: 'device',
                           shell=lambda *a, **kw: '1' if ready else '0')


@pytest.fixture
def adb(monkeypatch):
    monkeypatch.setattr(e, 'WINDOWS', True)
    monkeypatch.setattr(e, 'discover', lambda path='': [])
    monkeypatch.setattr(e, 'port_open', lambda port: False)
    monkeypatch.setattr(e.time, 'sleep', lambda seconds: None)
    mock = Mock()
    mock.device_list.return_value = []
    return mock


def test_bluestacks_configuration_is_backed_up_and_other_keys_preserved(tmp_path):
    conf = tmp_path / 'bluestacks.conf'
    original = b'bst.enable_adb_access="0"\r\nbst.enable_adb_remote_access="0"\r\nbst.instance.Pie64.adb_port="5555"\r\n'
    conf.write_bytes(original)
    assert e.parse_bluestacks(original.decode()) == {'Pie64': {5555}}
    assert e.enable_bluestacks_adb(conf, 'Pie64')
    assert conf.read_bytes() == original.replace(b'bst.enable_adb_access="0"', b'bst.enable_adb_access="1"')
    assert next(tmp_path.glob('*.bak')).read_bytes() == original
    assert not e.enable_bluestacks_adb(conf, 'Pie64')
    assert len(list(tmp_path.glob('*.bak'))) == 1


def test_unknown_config_is_not_rewritten(tmp_path):
    conf = tmp_path / 'unknown.conf'
    conf.write_bytes(b'newFormat = true\r\n')
    with pytest.raises(RuntimeError):
        e.enable_bluestacks_adb(conf, 'Pie64')
    assert not list(tmp_path.glob('*.bak'))


def test_ldplayer_enables_local_adb_without_root_or_remote(tmp_path):
    conf = tmp_path / 'leidian3.config'
    conf.write_bytes(b'{\r\n "basicSettings.adbDebug": 0, "basicSettings.rootMode": false\r\n}\r\n')
    original = conf.read_bytes()
    assert e.enable_ldplayer_adb(conf)
    assert conf.read_bytes() == original.replace(b'adbDebug": 0', b'adbDebug": 1')
    assert next(tmp_path.glob('*.bak')).read_bytes() == original
    assert json.loads(conf.read_bytes())['basicSettings.rootMode'] is False


def test_custom_executable_restricts_discovery_and_reads_instances(tmp_path, monkeypatch):
    monkeypatch.setattr(e, 'registry_roots', lambda: [])
    exe = tmp_path / 'HD-Player.exe'; exe.touch()
    (tmp_path / 'Nox.exe').touch()
    (tmp_path / 'bluestacks.conf').write_text('bst.instance.Pie64.adb_port="5565"\nbst.instance.Nougat32.adb_port="5555"')
    found = e.discover(str(exe))
    assert {x.name for x in found} == {'BlueStacks'}
    assert {x.instance: x.ports for x in found} == {'Nougat32': (5555,), 'Pie64': (5565,)}
    assert next(x for x in found if x.instance == 'Pie64').args == ('--instance', 'Pie64')


def test_ldplayer_console_alias_is_deduplicated(tmp_path, monkeypatch):
    monkeypatch.setattr(e, 'registry_roots', lambda: [])
    for name in ('ldconsole.exe', 'dnconsole.exe'): (tmp_path / name).touch()
    config = tmp_path / 'vms/config'; config.mkdir(parents=True)
    (config / 'leidian3.config').write_text('{"basicSettings.adbDebug": 0}')
    found = e.discover(str(tmp_path))
    assert len(found) == 1
    assert found[0].ports == (5561,)
    assert found[0].args == ('launch', '--index', '3')


def test_existing_emulator_reused_usb_ignored_and_no_server_connection(adb, monkeypatch):
    adb.device_list.return_value = [device('USB-phone'), device('127.0.0.1:5555')]
    seen = []
    monkeypatch.setattr(e, 'port_open', lambda p: seen.append(p) or False)
    assert e.prepare(adb, {'emulator_port': 5037}) == '127.0.0.1:5555'
    assert 5037 not in seen
    adb.server_kill.assert_not_called()


def test_aliases_do_not_look_like_two_devices(adb):
    adb.device_list.return_value = [device('emulator-5554'), device('127.0.0.1:5555')]
    assert e.prepare(adb, {}) == '127.0.0.1:5555'


def test_two_online_emulators_require_selection(adb):
    adb.device_list.return_value = [device('127.0.0.1:5555'), device('127.0.0.1:16384')]
    with pytest.raises(ConnectionError, match='Multiple emulators'):
        e.prepare(adb, {})
    assert e.prepare(adb, {'emulator_port': 16384}) == '127.0.0.1:16384'


def test_explicit_port_does_not_fall_back(adb, monkeypatch):
    adb.device_list.return_value = [device('127.0.0.1:5555')]
    monkeypatch.setattr(e.time, 'monotonic', Mock(side_effect=[0, 10]))
    with pytest.raises(ConnectionError, match='not ready'):
        e.prepare(adb, {'emulator_port': 16384, 'emulator_boot_timeout': 5})


def test_launch_enable_and_wait_for_android_in_order(adb, monkeypatch, tmp_path):
    conf = tmp_path / 'bluestacks.conf'; conf.write_text('bst.enable_adb_access="0"\n')
    candidate = e.Emulator('BlueStacks', tmp_path / 'HD-Player.exe', ('--instance', 'Pie64'), (5555,), conf, 'Pie64')
    monkeypatch.setattr(e, 'discover', lambda path='': [candidate])
    monkeypatch.setattr(e, 'is_running', lambda item: False)
    # Initial scan: none; next poll: connected, still booting; last poll: ready.
    adb.device_list.side_effect = [[], [device('127.0.0.1:5555', False)], [device('127.0.0.1:5555')]]
    launch = Mock(side_effect=lambda *a, **k: pytest.fail('ADB must be enabled before launch')
                  if '"0"' in conf.read_text() else None)
    monkeypatch.setattr(e.subprocess, 'Popen', launch)
    assert e.prepare(adb, {}) == '127.0.0.1:5555'
    launch.assert_called_once()
    assert launch.call_args.args[0][-2:] == ['--instance', 'Pie64']


def test_running_emulator_configuration_is_not_edited(adb, monkeypatch, tmp_path):
    conf = tmp_path / 'bluestacks.conf'; conf.write_text('bst.enable_adb_access="0"\n')
    candidate = e.Emulator('BlueStacks', tmp_path / 'HD-Player.exe', (), (5555,), conf, 'Pie64')
    monkeypatch.setattr(e, 'discover', lambda path='': [candidate])
    monkeypatch.setattr(e, 'is_running', lambda item: True)
    monkeypatch.setattr(e.subprocess, 'Popen', Mock())
    monkeypatch.setattr(e.time, 'monotonic', Mock(side_effect=[0, 10]))
    with pytest.raises(ConnectionError):
        e.prepare(adb, {'emulator_boot_timeout': 5})
    assert '"0"' in conf.read_text()
    assert not list(tmp_path.glob('*.bak'))


def test_auto_emulator_off_never_launches_or_edits(adb, monkeypatch, tmp_path):
    candidate = e.Emulator('LDPlayer', tmp_path / 'ldconsole.exe', (), (5555,))
    monkeypatch.setattr(e, 'discover', lambda path='': [candidate])
    launch = Mock(); monkeypatch.setattr(e.subprocess, 'Popen', launch)
    monkeypatch.setattr(e.time, 'monotonic', Mock(side_effect=[0, 10]))
    with pytest.raises(ConnectionError):
        e.prepare(adb, {'auto_emulator': False, 'emulator_boot_timeout': 5})
    launch.assert_not_called()


def test_game_start_requires_installed_valid_package(adb):
    adb.device.return_value.list_packages.return_value = ['com.supercell.brawlstars']
    e.start_game(adb, '127.0.0.1:5555', {})
    adb.device.return_value.app_start.assert_called_once_with('com.supercell.brawlstars')
    with pytest.raises(ValueError):
        e.start_game(adb, '127.0.0.1:5555', {'brawl_stars_package': 'com.x; something'})
    adb.device.return_value.list_packages.return_value = []
    with pytest.raises(RuntimeError, match='Install'):
        e.start_game(adb, '127.0.0.1:5555', {})


@pytest.mark.parametrize('config', [{'emulator_port': -1}, {'emulator_port': 65536},
                                    {'emulator_port': 1.5}, {'emulator_boot_timeout': 0},
                                    {'emulator_instance': '../bad'}])
def test_bad_settings_fail_before_adb(config, adb):
    with pytest.raises(ValueError): e.prepare(adb, config)
    adb.server_start.assert_not_called()


def test_reconnect_remembers_selected_device(monkeypatch):
    source = Path('window_controller.py').read_text()
    tree = ast.parse(source)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'WindowController')
    method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'force_rediscover')
    rediscover = Mock(return_value=device('127.0.0.1:5555'))
    adb = Mock()
    namespace = {'adb': adb, 'discover_device': rediscover}
    exec(compile(ast.Module(body=[method], type_ignores=[]), 'window_controller.py', 'exec'), namespace)
    ctrl = SimpleNamespace(scrcpy_client=Mock(), device=device('127.0.0.1:5555'), verbose_debug=False)
    assert namespace['force_rediscover'](ctrl)
    rediscover.assert_called_once_with(False, reconnect_serial='127.0.0.1:5555')
    adb.server_kill.assert_not_called()

import math
import unittest
from unittest.mock import Mock, patch
import cv2
import numpy as np
from brawl_ball import AutoGoal, BallObservation, BallVision, find_player_bar, path_waypoint, shooting_approach, find_brawl_ball_result
from tests.iris_input_support import controller


class AutoGoalTests(unittest.TestCase):
    def setUp(self):
        self.goal = AutoGoal()
        self.window = Mock(width_ratio=1., height_ratio=1.)
        self.window.aim_attack.return_value = True
        self.frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
        # Player feet at (480, 300) in the normalized image.
        self.data = {'player': [[864, 400, 1056, 653]], 'teammate': [], 'enemy': [], 'wall': []}

    def observe(self, ball=(480, 270), goal=(480, 130), active=True):
        self.goal.vision.observe = Mock(return_value=BallObservation(active, ball, goal, .9))

    def test_other_modes_do_not_take_over_or_shoot(self):
        self.observe(active=False)
        self.assertIsNone(self.goal.decide(self.frame, self.data, self.window, 1))
        self.window.aim_attack.assert_not_called()

    def test_match_over_score_recovers_result_without_a_later_result_page(self):
        from state_finder import get_state
        for name,expected in [('last_goal','defeat'),('clock_expiry','victory'),
                              ('last_goal_win','victory'),('clock_expiry_loss','defeat')]:
            for size in ((960,540),(1280,720),(1920,1080)):
                with self.subTest(name=name,size=size):
                    frame=cv2.cvtColor(cv2.imread(f'tests/fixtures/brawl_ball/{name}.jpg'),cv2.COLOR_BGR2RGB)
                    frame=cv2.resize(frame,size)
                    self.assertEqual(find_brawl_ball_result(frame),expected)
                    self.assertEqual(get_state(frame),'end_'+expected)

    def test_result_requires_finished_banner_and_readable_score_on_both_sides(self):
        for name in ('kickoff','rolling','highlight','held_turn'):
            frame=cv2.cvtColor(cv2.imread(f'tests/fixtures/brawl_ball/{name}.jpg'),cv2.COLOR_BGR2RGB)
            self.assertIsNone(find_brawl_ball_result(frame),name)
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/last_goal.jpg'),cv2.COLOR_BGR2RGB)
        frame[8:55,815:890]=0
        self.assertIsNone(find_brawl_ball_result(frame))

    def test_match_over_artwork_without_two_football_icons_cannot_report_a_result(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/last_goal.jpg'),cv2.COLOR_BGR2RGB)
        frame[:65,:75]=0
        self.assertIsNone(find_brawl_ball_result(frame))

    def test_close_ball_must_be_confirmed_before_shooting(self):
        self.observe()
        self.goal.decide(self.frame, self.data, self.window, 1)
        self.window.aim_attack.assert_not_called()
        self.goal.decide(self.frame, self.data, self.window, 1.25)
        self.window.aim_attack.assert_called_once_with(0., -170.)
        self.window.release_movement.assert_called_once()

    def test_own_goal_or_missing_goal_never_triggers_shot(self):
        for target in ((480, 450), None):
            with self.subTest(target=target):
                self.goal.reset(); self.observe(goal=target)
                self.goal.decide(self.frame, self.data, self.window, 1)
                self.goal.decide(self.frame, self.data, self.window, 1.25)
        self.window.aim_attack.assert_not_called()

    def test_ball_closer_to_teammate_is_not_assumed_owned(self):
        self.observe()
        self.data['teammate'] = [[864, 360, 1056, 593]]
        for now in (1, 1.25, 2):
            self.goal.decide(self.frame, self.data, self.window, now)
        self.window.aim_attack.assert_not_called()
        self.assertEqual(self.goal.phase, 'collect')

    def test_wall_in_shot_path_requires_carrying_around_it(self):
        self.observe()
        self.data['wall'] = [[900, 390, 1020, 450]]
        self.goal.decide(self.frame, self.data, self.window, 1)
        self.goal.decide(self.frame, self.data, self.window, 1.25)
        self.assertEqual(self.goal.phase, 'carry')
        self.window.aim_attack.assert_not_called()

    def test_lost_ball_does_not_fire_from_cached_possession(self):
        self.observe(goal=None)
        self.goal.decide(self.frame, self.data, self.window, 1)
        self.goal.decide(self.frame, self.data, self.window, 1.25)
        self.observe(ball=None)
        self.goal.decide(self.frame, self.data, self.window, 1.3)
        self.window.aim_attack.assert_not_called()

    def test_short_occlusion_keeps_carry_direction_without_shooting(self):
        self.observe(goal=None)
        self.goal.decide(self.frame,self.data,self.window,1)
        self.goal.decide(self.frame,self.data,self.window,1.25)
        self.observe(ball=None,goal=None)
        self.goal.decide(self.frame,self.data,self.window,1.8)
        self.assertEqual(self.goal.phase,'carry')
        self.window.aim_attack.assert_not_called()

    def test_separated_ball_clears_remembered_possession(self):
        self.observe(goal=None)
        self.goal.decide(self.frame,self.data,self.window,1)
        self.goal.decide(self.frame,self.data,self.window,1.25)
        self.observe(ball=(200,180),goal=None)
        self.goal.decide(self.frame,self.data,self.window,1.4)
        self.assertEqual(self.goal.phase,'collect')
        self.window.aim_attack.assert_not_called()

    def test_turning_with_carried_ball_does_not_reverse_toward_a_stale_nearby_position(self):
        self.observe(goal=None)
        self.goal.decide(self.frame,self.data,self.window,1)
        self.goal.decide(self.frame,self.data,self.window,1.25)
        self.observe(ball=(410,300),goal=None)
        self.goal.decide(self.frame,self.data,self.window,1.5)
        self.assertEqual(self.goal.phase,'carry')
        self.assertEqual(self.goal.navigation['target'],(480,45))
        self.window.aim_attack.assert_not_called()

    def test_enabled_gadget_revokes_cached_possession_even_when_ball_is_occluded(self):
        self.observe(goal=None)
        self.goal.decide(self.frame,self.data,self.window,1)
        self.goal.decide(self.frame,self.data,self.window,1.25)
        self.observe(ball=None,goal=None)
        with patch('brawl_ball.gadget_available',return_value=True):
            self.goal.decide(self.frame,self.data,self.window,1.4)
        self.assertEqual(self.goal.phase,'search')
        self.window.aim_attack.assert_not_called()

    def test_brief_goal_occlusion_keeps_navigation_target_without_a_blind_shot(self):
        self.observe(goal=(480,65))
        self.goal.decide(self.frame,self.data,self.window,1)
        self.goal.decide(self.frame,self.data,self.window,1.25)
        self.observe(ball=None,goal=None)
        self.goal.decide(self.frame,self.data,self.window,1.5)
        self.assertEqual(self.goal.navigation['target'],shooting_approach((480,300),(480,65),[]))
        self.window.aim_attack.assert_not_called()

    def test_recorded_held_ball_survives_a_higher_scoring_rejected_candidate(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/held_ball.jpg'),cv2.COLOR_BGR2RGB)
        result=BallVision().observe(frame,1,player=(320.5,293.5))
        self.assertIsNotNone(result.ball)
        self.assertLess(math.dist(result.ball,(323,305)),8)
        self.assertTrue(result.ring_visible)

    def test_held_ball_remains_visible_through_turn_and_character_overlap(self):
        cases=[('held_overlap',(567,278.5),(565,239)),
               ('held_turn',(537,281.5),(565,253))]
        for name,player,expected in cases:
            for size in ((960,540),(1920,1080),(1280,720)):
                with self.subTest(name=name,size=size):
                    frame=cv2.cvtColor(cv2.imread(f'tests/fixtures/brawl_ball/{name}.jpg'),cv2.COLOR_BGR2RGB)
                    frame=cv2.resize(frame,size)
                    vision=BallVision()
                    kickoff=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/kickoff.jpg'),cv2.COLOR_BGR2RGB)
                    self.assertTrue(vision.observe(kickoff,1).active)
                    # This is a carrying sequence in an already confirmed
                    # match, with the score HUD partially obscured by effects.
                    result=vision.observe(frame,20,player=player,owned_recently=True)
                    self.assertIsNotNone(result.ball)
                    self.assertLess(math.dist(result.ball,expected),9)
                    self.assertTrue(result.ring_visible)

    def test_white_costume_is_rejected_even_during_recent_possession(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/white_hat.jpg'),cv2.COLOR_BGR2RGB)
        result=BallVision().observe(frame,1,player=(555.5,325.5),owned_recently=True)
        self.assertIsNone(result.ball)

    def test_available_gadget_prevents_false_shot_at_a_nearby_loose_ball(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/loose_near_player.jpg'),cv2.COLOR_BGR2RGB)
        frame=cv2.resize(frame,(1920,1080))
        self.observe()
        for now in (1,1.25,1.5):self.goal.decide(frame,self.data,self.window,now)
        self.assertEqual(self.goal.phase,'collect')
        self.window.aim_attack.assert_not_called()

    def test_collecting_attacks_nearby_enemy_only_with_positive_free_hands_cue(self):
        self.observe(ball=(200,100),goal=None)
        self.data['enemy']=[[944,400,1136,653]]
        with patch('brawl_ball.gadget_available',return_value=True):
            for now in (1,1.1,1.2):
                self.goal.decide(self.frame,self.data,self.window,now,attack_range=192)
        self.window.press.assert_called_once_with('attack')

    def test_carrying_or_uncertain_hands_never_auto_attack(self):
        self.observe(goal=None)
        self.data['enemy']=[[944,400,1136,653]]
        with patch('brawl_ball.gadget_available',return_value=False):
            for now in (1,1.25,1.6):
                self.goal.decide(self.frame,self.data,self.window,now,attack_range=192)
        self.window.press.assert_not_called()

    def test_wall_blocks_collecting_attack(self):
        self.observe(ball=(200,100),goal=None)
        self.data['enemy']=[[1024,400,1216,653]]
        self.data['wall']=[[1000,500,1040,630]]
        with patch('brawl_ball.gadget_available',return_value=True):
            self.goal.decide(self.frame,self.data,self.window,1,attack_range=192)
        self.window.press.assert_not_called()

    def test_successful_shot_has_cooldown(self):
        self.observe()
        for now in (1, 1.25, 1.3, 1.5, 1.7):
            self.goal.decide(self.frame, self.data, self.window, now)
        self.window.aim_attack.assert_called_once()

    def test_path_routes_to_side_of_wall(self):
        waypoint = path_waypoint((480, 320), (480, 100), [(450, 240, 510, 280)])
        self.assertNotEqual(waypoint[0], 480)
        self.assertGreaterEqual(waypoint[1], 296)

    def test_attack_drag_is_scaled_and_releases_after_failure(self):
        value = controller()
        value.scrcpy_client.resolution = (1280, 720)
        value.touch_down = Mock(return_value=True)
        value.touch_move = Mock(return_value=False)
        value.touch_up = Mock(return_value=True)
        with patch('window_controller.time.sleep'):
            self.assertFalse(value.aim_attack(0, -100))
        from window_controller import press_coords_dict
        self.assertEqual(value.touch_down.call_args.args[0], int(press_coords_dict["attack"][0] * 1280 / 1920))
        value.touch_up.assert_called_once()

    def test_blank_menu_is_not_game_or_player(self):
        self.assertFalse(self.goal.vision.observe(self.frame, 1).active)
        self.assertIsNone(find_player_bar(self.frame))

    def test_only_one_score_icon_is_not_enough(self):
        icon=cv2.cvtColor(cv2.imread('images/brawl_ball/score_icon.png'),cv2.COLOR_BGR2RGB)
        h,w=icon.shape[:2]
        self.frame[28:28+h,42:42+w]=icon
        self.assertFalse(self.goal.vision.observe(self.frame, 1).active)

    def test_hud_occlusion_keeps_known_mode_only_until_between_match_reset(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/kickoff.jpg'),cv2.COLOR_BGR2RGB)
        vision=BallVision()
        self.assertTrue(vision.observe(frame,1).active)
        frame[:130]=0
        vision.reset(keep_mode=True)
        self.assertTrue(vision.observe(frame,2).active)
        self.assertTrue(vision.observe(frame,60).active)
        vision.reset()
        self.assertFalse(vision.observe(frame,61).active)

    def test_health_bar_without_player_name_is_rejected(self):
        cv2.rectangle(self.frame,(850,400),(950,414),(90,255,0),-1)
        self.assertIsNone(find_player_bar(self.frame))

    def test_recorded_frames_recognize_ball_goal_and_kickoff_at_multiple_sizes(self):
        for size in ((1920,1080),(1280,720)):
            for name in ('kickoff','rolling','opponent_goal','near_player','result'):
                with self.subTest(size=size, name=name):
                    frame=cv2.cvtColor(cv2.imread(f'tests/fixtures/brawl_ball/{name}.jpg'),cv2.COLOR_BGR2RGB)
                    frame=cv2.resize(frame,size)
                    vision=BallVision()
                    result=vision.observe(frame,1)
                    self.assertEqual(result.active,name!='result')
                    if name in ('rolling','near_player'):
                        self.assertIsNotNone(result.ball)
                    if name=='opponent_goal':
                        self.assertIsNotNone(result.goal)
                        self.assertLess(result.goal[1],200)
                    if name=='kickoff':
                        self.assertIsNotNone(find_player_bar(frame))

    def test_offscreen_indicator_guides_search_back_toward_ball(self):
        self.goal.vision.observe = Mock(return_value=BallObservation(True, None, None, .1, (480,500)))
        movement=self.goal.decide(self.frame,self.data,self.window,1)
        self.assertGreater(movement[1],0)
        self.window.aim_attack.assert_not_called()

    def test_recorded_offscreen_marker_is_detected_with_different_arrow_color(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/offscreen.jpg'),cv2.COLOR_BGR2RGB)
        observation=self.goal.vision.observe(frame,1)
        self.assertIsNotNone(observation.guide)
        self.assertLess(observation.guide[1],80)

    def test_highlight_on_ball_is_accepted_but_white_hat_is_rejected(self):
        for name, expected in [('lit_ball',True),('white_hat',False)]:
            with self.subTest(name=name):
                frame=cv2.cvtColor(cv2.imread(f'tests/fixtures/brawl_ball/{name}.jpg'),cv2.COLOR_BGR2RGB)
                result=BallVision().observe(frame,1)
                self.assertEqual(result.ball is not None, expected)

    def test_overlapping_wall_detection_does_not_return_zero_forever(self):
        p=path_waypoint((480,300),(480,60),[(450,270,510,320)])
        self.assertNotEqual(p,(480,300))

    def test_first_visible_player_overrides_stale_intro_without_waiting(self):
        import threading
        from play import Play
        play=Play.__new__(Play)
        play.match_logger=Mock(enabled=False)
        play.is_super_ready=play.is_gadget_ready=play.is_hypercharge_ready=False
        play.normal_recovery=Mock()
        play.last_water_data=[]
        play.last_rope_fence_data=[]
        play._closed=False
        play._was_playing=False
        play.auto_goal=Mock()
        play.round_start = Mock()
        play.round_start.update.return_value = None
        play.window_controller=self.window
        play.time_since_walls_checked=100
        play.walls_treshold=1
        play.centered_wall_detection=False
        play.get_main_data=Mock(return_value={})
        play.last_walls_data=[]
        play.last_bushes_data=[]
        play.time_since_detections={'player':0,'enemy':0}
        play.fix_movement_keys={'toggled':False}
        play._cache_lock=threading.RLock()
        play.hypercharge_treshold=play.gadget_treshold=play.super_treshold=5
        play.time_since_hypercharge_checked=play.time_since_gadget_checked=play.time_since_super_checked=100
        play.loop=Mock(return_value=(0,-75))
        play.publish_debug_view=Mock()
        main=Mock()
        main.get_latest_state.return_value='match_intro'
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/kickoff.jpg'),cv2.COLOR_BGR2RGB)
        with patch('play.time.time',return_value=100),patch('play.get_config',return_value=False):
            play.main(frame,'elprimo',main)
        main.set_latest_state.assert_called_once_with('match')
        self.window.move.assert_called_once_with(0.,-75.)
        self.assertTrue(play._was_playing)


if __name__ == '__main__':
    unittest.main()

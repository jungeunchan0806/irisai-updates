from pathlib import Path
from unittest.mock import Mock, patch
import cv2
import pytest
from play import Play
from utils import load_pyla_script


def test_models_iris_farm_styles_and_goal_controller_work_together():
    frame = cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/kickoff.jpg'), cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (1920, 1080))
    window = Mock(width=1920, height=1080, width_ratio=1., height_ratio=1., scale_factor=1.,
                  movement_joystick_x=220, movement_joystick_y=870)
    meta, code = load_pyla_script('iris_aggressive_balanced.pyla')
    play = Play('models/mainInGameModel.onnx', 'models/tileDetector.onnx', window, code)
    play.match_logger.enabled = False
    main = Mock()
    main.get_latest_state.return_value = 'match'
    main.Stage_manager.playstyle_info = meta
    play.main(frame, 'shelly', main)
    assert window.move.call_count > 0
    for path in Path('playstyles').glob('iris_*.pyla'):
        _, code = load_pyla_script(path.name)
        play.pyla_code = compile(code, str(path), 'exec')
        result = play.get_movement()
        assert result is not None, path.name
    window.move.reset_mock()
    with patch('play.get_config', return_value=True):
        play.main(frame, 'shelly', main)
    assert play.auto_goal.phase != 'waiting_for_brawl_ball'
    assert window.move.called
    window.move.reset_mock()
    window.press.reset_mock()
    play.main(frame, 'shelly', main, frame_time=1)
    assert not window.move.called
    assert not window.press.called
    window.release_movement.assert_called()

import json
import math
from pathlib import Path
import unittest
from unittest.mock import Mock,patch

import cv2
import numpy as np

from brawl_ball import find_player_bar, own_goal_exit, own_goal_rail, path_waypoint, shooting_approach
from navigation import CameraMotion, MovementRecovery, wall_footprints, segment_clear


class NavigationTests(unittest.TestCase):
    def test_recorded_opponent_goal_routes_to_shooting_lane_in_front_of_side_post(self):
        data=json.loads(Path('tests/fixtures/brawl_ball/opponent_goal_geometry.json').read_text())
        player,goal,walls=data['player'],data['goal'],data['walls']
        target=shooting_approach(player,goal,walls)
        self.assertTrue(segment_clear(target,goal,walls,radius=6))
        for _ in range(200):
            waypoint=path_waypoint(player,target,walls)
            length=math.dist(player,waypoint)
            self.assertGreater(length,.01)
            player=tuple(a+(b-a)/length*min(2,length) for a,b in zip(player,waypoint))
            self.assertGreater(player[1],goal[1]+100,'Route cut behind the solid goal post')
            if math.dist(player,target)<12:break
        self.assertLess(math.dist(player,target),12)

    def test_normal_combat_leaves_goal_before_chasing_enemy_through_side_post(self):
        from play import Play
        from brawl_ball import AutoGoal
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/goal_trap.jpg'),cv2.COLOR_BGR2RGB)
        recorded=json.loads(Path('tests/fixtures/brawl_ball/goal_trap.json').read_text())
        play=Play.__new__(Play);play.frame=frame;play.auto_goal=AutoGoal()
        play.window_controller=Mock(width_ratio=1.,height_ratio=1.)
        play.normal_recovery=Mock(status='moving',recoveries=0)
        play.normal_recovery.displacement.return_value=50.
        play.normal_recovery.adjust.side_effect=lambda frame,p,a,e,w,m,n:m
        data={'player':[recorded['player']],'wall':recorded['walls'],'enemy':[],'teammate':[]}
        with patch('play.find_player_bar',return_value=None):
            command=play.navigate_playstyle_movement(data,(-75,0),1)
        rail=own_goal_rail(frame)
        self.assertLess(play.normal_navigation['target'][1],rail[2]-50)
        self.assertGreater(math.hypot(*command),70)

    def test_intentionally_stopped_playstyle_is_not_forced_to_move(self):
        from play import Play
        play=Play.__new__(Play);play.normal_recovery=Mock()
        self.assertEqual(play.navigate_playstyle_movement({},(0,0),1),(0,0))
        play.normal_recovery.reset.assert_called_once()

    def test_recorded_goal_trap_has_a_continuous_route_out(self):
        base = Path('tests/fixtures/brawl_ball/goal_trap')
        frame = cv2.cvtColor(cv2.imread(str(base.with_suffix('.jpg'))), cv2.COLOR_BGR2RGB)
        data = json.loads(base.with_suffix('.json').read_text())
        walls = wall_footprints([tuple(v/2 for v in b) for b in data['walls']])
        w,x,y,_ = own_goal_rail(frame)
        walls.extend([(0,y+5,x+16,540),(x+w-16,y+5,960,540)])
        p = (498.,310.)
        for _ in range(300):
            target = own_goal_exit(frame,p) or (480,65)
            q = path_waypoint(p,target,walls)
            distance = math.dist(p,q)
            self.assertGreater(distance,.01,'Route stopped against the front wall')
            p = tuple(a+(b-a)/distance*min(2,distance) for a,b in zip(p,q))
            for x1,y1,x2,y2 in walls:
                self.assertFalse(x1-12 < p[0] < x2+12 and y1-12 < p[1] < y2+12,
                                 'The continuous route cut through a tile or goal post')
            if p[1] < 120:
                break
        self.assertLess(p[1],120,'The player did not leave the goal')

    def test_shielded_hp_outline_is_a_stable_anchor_with_entity_hint(self):
        frame = cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/goal_trap.jpg'),cv2.COLOR_BGR2RGB)
        box = [892,411,1087,666]
        bar = find_player_bar(frame,hint=box)
        self.assertIsNotNone(bar)
        self.assertLess(abs((bar[0]+bar[2])/2-996),10)
        self.assertLess(abs(bar[1]-410),10)

    def test_shielded_player_is_detected_before_any_damage_without_model_hint(self):
        frame=cv2.cvtColor(cv2.imread('tests/fixtures/brawl_ball/goal_trap.jpg'),cv2.COLOR_BGR2RGB)
        bar=find_player_bar(frame)
        self.assertIsNotNone(bar)
        self.assertLess(abs((bar[0]+bar[2])/2-996),10)
        self.assertLess(abs(bar[1]-410),10)

    def test_camera_scroll_is_measured_without_player_motion(self):
        rng = np.random.default_rng(42)
        frame = np.zeros((540,960,3),np.uint8)
        for x,y in rng.integers([170,85],[790,425],size=(90,2)):
            cv2.rectangle(frame,(x,y),(x+9,y+9),(220,210,180),-1)
        camera = CameraMotion()
        camera.update(frame,[],0)
        moved = cv2.warpAffine(frame,np.float32([[1,0,0],[0,1,10]]),(960,540))
        dx,dy = camera.update(moved,[],.2)
        self.assertAlmostEqual(dx,0,delta=1)
        self.assertAlmostEqual(dy,10,delta=1)

    def test_stationary_anchor_triggers_and_holds_escape_despite_foot_animation(self):
        r = MovementRecovery();frame=np.zeros((540,960,3),np.uint8)
        for i in range(9):
            movement = r.adjust(frame,(480,300+10*(i%2)),(480,220),[],[],(0,-75),i*.2)
        self.assertEqual(r.status,'escaping')
        direction = movement
        for i in range(9,12):
            movement = r.adjust(frame,(480,300),(480,220),[],[],(0,-75),i*.2)
            self.assertEqual(movement,direction)

    def test_progress_with_following_camera_does_not_trigger_escape(self):
        r=MovementRecovery();frame=np.zeros((540,960,3),np.uint8)
        r.camera.update=lambda *args:(0.,5.)
        for i in range(20):
            movement=r.adjust(frame,(480,300),(480,220),[],[],(0,-75),i*.2)
        self.assertIsNone(r.escape)
        self.assertEqual(movement,(0,-75))

    def test_corner_escape_chooses_the_open_backwards_route(self):
        r=MovementRecovery();r._world=np.array([480.,300.])
        walls=[(440,240,520,270),(420,250,450,360),(510,250,540,360)]
        r.choose_escape((480,300),(0,-75),walls,1)
        self.assertGreater(r.escape[1],.9)
        self.assertLess(abs(r.escape[0]),.1)

    def test_failed_escape_is_not_repeated_forever(self):
        r=MovementRecovery();r._world=np.array([480.,300.])
        r.choose_escape((480,300),(0,-75),[],1)
        first=r.escape;r.failed.append((2,first))
        r.choose_escape((480,300),(0,-75),[],2)
        self.assertLess(np.dot(first,r.escape),.8)

    def test_escaping_overlapping_detection_can_move_out(self):
        room=MovementRecovery.clearance((480,300),(-1,0),[(475,275,515,325)])
        self.assertGreater(room,90)


if __name__=='__main__':
    unittest.main()

globalThis.__irisPatchFixture = true; export default true;
